﻿using UnityEngine;
using System.Collections;

public class Pokedex : MonoBehaviour {
	public static Pokedex S;
	// Use this for initialization
	void Awake(){
		S = this;

	}
	void Start () {
		gameObject.SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.A) || Input.GetKeyDown (KeyCode.S)) {
			gameObject.SetActive(false);
			Menu.S.isSelected = false;
		}
	}
}
