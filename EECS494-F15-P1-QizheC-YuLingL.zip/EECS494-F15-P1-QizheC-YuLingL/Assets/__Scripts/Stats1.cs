﻿using UnityEngine;
using System.Collections;

public class Stats1 : MonoBehaviour {
	public static Stats1 S;
	public GameObject stats;
	public GameObject name;
	public GameObject level;
	public GameObject healthBar;
	public GameObject status;
	public GameObject picture;
	public GameObject type1;
	public GameObject attribute1;
	public GameObject type2;
	public GameObject attribute2;

	public float maxBarLength;
	public float curBarLength;
	public GUITexture display;
	void Awake(){
		S = this;
	}
	// Use this for initialization
	void Start () {
		foreach (Transform  child in transform) {
			if(child.gameObject.name == "stats"){
				stats = child.gameObject;
			}
			else if(child.gameObject.name == "Name"){
				name = child.gameObject;
			}
			else if(child.gameObject.name == "Level"){
				level = child.gameObject;
			}
			else if(child.gameObject.name == "HealthBar"){
				healthBar = child.gameObject;
				display = healthBar.GetComponent<GUITexture> ();
				maxBarLength = display.pixelInset.width;
			}
			else if(child.gameObject.name == "status"){
				status = child.gameObject;
			}
			else if(child.gameObject.name == "Picture"){
				picture = child.gameObject;
			}
			else if(child.gameObject.name == "TYPE1"){
				type1 = child.gameObject;
			}
			else if(child.gameObject.name == "attribute1"){
				attribute1 = child.gameObject;
			}
			else if(child.gameObject.name == "TYPE2"){
				type2 = child.gameObject;
			}
			else if(child.gameObject.name == "attribute2"){
				attribute2 = child.gameObject;
			}
			//gameObject.SetActive(false);
		}
	}
	
	// Update is called once per frame
	void Update () {
			name.GetComponent<GUIText>().text = Party.S.selectedP.name;
			level.GetComponent<GUIText>().text = ":L" + Party.S.selectedP.level.ToString();
			curBarLength = ((float)Party.S.selectedP.HP / Party.S.selectedP.MaxHP) * maxBarLength;
			display.pixelInset = new Rect (display.pixelInset.x, display.pixelInset.y, curBarLength, display.pixelInset.height);
			picture.GetComponent<GUITexture>().texture = Resources.Load(Party.S.selectedP.path_norm) as Texture2D;
			if(Party.S.selectedP.type == Type.ELECTRIC)
				attribute1.GetComponent<GUIText>().text = "ELECTRIC";
			else if(Party.S.selectedP.type == Type.FIRE)
				attribute1.GetComponent<GUIText>().text = "FIRE";
			else if(Party.S.selectedP.type == Type.GRASS)
				attribute1.GetComponent<GUIText>().text = "GRASS";
			else if(Party.S.selectedP.type == Type.NORMAL)
				attribute1.GetComponent<GUIText>().text = "NORMAL";
			else if(Party.S.selectedP.type == Type.WATER)
				attribute1.GetComponent<GUIText>().text = "WATER";
			type2.GetComponent<GUIText>().text = "";
			foreach(Transform child in stats.transform){
				if(child.gameObject.name == "Attack"){
					child.gameObject.GetComponent<GUIText>().text = Party.S.selectedP.atk.ToString();
				}
				if(child.gameObject.name == "Defense"){
					child.gameObject.GetComponent<GUIText>().text = Party.S.selectedP.def.ToString();
				}
				if(child.gameObject.name == "Speed"){
					child.gameObject.GetComponent<GUIText>().text = Party.S.selectedP.speed.ToString();
				}
				if(child.gameObject.name == "Special"){
					child.gameObject.GetComponent<GUIText>().text = Party.S.selectedP.special.ToString();
				}
			}
	}
}
