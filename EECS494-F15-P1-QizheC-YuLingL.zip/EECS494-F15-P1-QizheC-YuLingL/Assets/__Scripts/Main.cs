﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
public class Main : MonoBehaviour {

	static public Main S;

	public bool inDialog = false;
	public bool paused = false;
	public bool isVincible = false;
	public GameObject vincible;

	public bool battle = false;
	public bool isOption = false;
	public bool isMove = false;
	public bool isSelected = false;
	public bool talkeToOak = false;
	public bool npc_move = false;
	public bool isbeginning = true;
	void Awake(){
		S = this;
		PokemonData.start ();

	}
	// Use this for initialization
	void Start () {
		vincible = GameObject.Find ("Invincible");
		vincible.SetActive (false);
		isVincible = false;
	}
	
	// Update is called once per frame
	void Update () {
		if (isbeginning) {
			Dialog.S.ShowMessage(Dialog.S.background[0]);
			isbeginning = false;
			Dialog.S.beginDialog = true;
		}
		if (!inDialog && Input.GetKeyDown (KeyCode.Return) && !battle && !paused) {
			Menu.S.gameObject.SetActive(true);

			paused = true;
		}
		else if (!inDialog && Input.GetKeyDown (KeyCode.I)) {
			isVincible = isVincible ^ true;
			vincible.SetActive(isVincible);
		}
	}
	public static IEnumerator Wait() {
		print(Time.time);
		yield return new WaitForSeconds(2);
		print(Time.time);
	}
	public bool canEnterBattle(){
		bool isHP = false;
		foreach (KeyValuePair<string,PokemonAttribute> poke in MyPokemon.DictPokemon) {
			if(poke.Value.HP > 0)
				isHP =true;
		}
		if (isHP == false)
			return false;
		return true;
	}
	public void enterBattle(string input, bool isNPC){
		if (canEnterBattle () == false) {
			Dialog.S.ShowMessage("You pokemon no health!");
			return;
		}
		print (Random.Range(0, EnemyPokemon.EnemyList.Count));
		BattleText.S.isNPC = isNPC;
		if (isNPC) {
			EnemyPokemon.S.gameObject.SetActive (false);
			NPCStart.S.gameObject.SetActive(true);
		} else {
			EnemyPokemon.S.hideAttribute();
			NPCStart.S.gameObject.SetActive(false);
		}
		if (MyPokemon.current == null) {
			MyPokemon.current = MyPokemon.DictPokemon.Values.First();
		}
		int index = Random.Range(0, EnemyPokemon.EnemyList.Count);
		PokemonAttribute newOne = new PokemonAttribute();
		newOne.name = EnemyPokemon.EnemyList [index].name;
		newOne.HP = EnemyPokemon.EnemyList [index].HP;
		newOne.atk = EnemyPokemon.EnemyList [index].atk;
		newOne.def = EnemyPokemon.EnemyList [index].def;
		newOne.special = EnemyPokemon.EnemyList [index].special;
		newOne.speed = EnemyPokemon.EnemyList [index].speed;
		newOne.level = EnemyPokemon.EnemyList [index].level;
		newOne.Move1 = EnemyPokemon.EnemyList [index].Move1;
		newOne.Move1PP = PokemonData.DictMove[newOne.Move1].MaxPP;
		newOne.path_back = EnemyPokemon.EnemyList [index].path_back;
		newOne.path_norm = EnemyPokemon.EnemyList [index].path_norm;
		newOne.MaxHP = EnemyPokemon.EnemyList [index].MaxHP;
		newOne.HP = EnemyPokemon.EnemyList [index].HP;

		EnemyPokemon.S.current = newOne;


		EnemyPokemon.S.current.HP = EnemyPokemon.S.current.MaxHP;
		battle = true;
		isOption = false;
		isMove = false;
		Battle.S.gameObject.SetActive(true);
		ShowMyBall.S.gameObject.SetActive (true);
		Option.S.gameObject.SetActive(false);
		MyPokemon.S.gameObject.SetActive (false);
		BattleText.S.gameObject.SetActive(true);
		Move.S.gameObject.SetActive (false);
		BattleText.S.displayText(input);
		BattleText.S.isStart = true;


	}
	public void exitBattle(){
		bool restart = true;
		foreach(KeyValuePair<string,PokemonAttribute> item in MyPokemon.DictPokemon){
			if(item.Value.HP != 0)
				restart = false;
		}
		print (restart);
		if (restart) {
			Mary_Lou_Dorf.S.isfight = false;
			Mary_Lou_Dorf.S.hasfight = false;
			Deorio.S.isfight = false;
			Deorio.S.hasfight = false;
			Jeremy_bond.S.isfight = false;
			Jeremy_bond.S.hasfight = false;
			Player.S.hasMaryKey = false;
			Player.S.DeOrioKey = 0;
			Mary_Lou_Dorf.S.gameObject.SetActive (true);
			Deorio.S.gameObject.SetActive (true);
			foreach(GameObject ball in Player.S.ballList){
				ball.SetActive(true);
			}
			Player.S.ballList = new List<GameObject>();
			NPC.battle1 = 0f;
			NPC.battle2 = 0f;
			NPC.battle3 = 0f;
			NPC.battle4 = 0f;
			NPC.battle5 = 0f;
		} else if (BattleText.S.isMary) {
			Mary_Lou_Dorf.S.gameObject.SetActive(false);
		}
		if (BattleText.S.isMary) {
			foreach(PokemonAttribute p in Mary_Lou_Dorf.S.pokemonList){
				p.HP = p.MaxHP;
				p.Move1PP = PokemonData.DictMove[p.Move1].MaxPP;
				if(p.Move2 != null)
					p.Move2PP = PokemonData.DictMove[p.Move2].MaxPP;
				if(p.Move3 != null)
					p.Move3PP = PokemonData.DictMove[p.Move3].MaxPP;
			}
			Mary_Lou_Dorf.S.currentPokemon = 0;
		}
		if (BattleText.S.isDe) {
			foreach(PokemonAttribute p in Deorio.S.pokemonList){
				p.HP = p.MaxHP;
				p.Move1PP = PokemonData.DictMove[p.Move1].MaxPP;
				if(p.Move2 != null)
					p.Move2PP = PokemonData.DictMove[p.Move2].MaxPP;
				if(p.Move3 != null)
					p.Move3PP = PokemonData.DictMove[p.Move3].MaxPP;
			}
			Deorio.S.currentPokemon = 0;
		}

		if (BattleText.S.isGib) {
			foreach(PokemonAttribute p in Jeremy_bond.S.pokemonList){
				p.HP = p.MaxHP;
				p.Move1PP = PokemonData.DictMove[p.Move1].MaxPP;
				if(p.Move2 != null)
					p.Move2PP = PokemonData.DictMove[p.Move2].MaxPP;
				if(p.Move3 != null)
					p.Move3PP = PokemonData.DictMove[p.Move3].MaxPP;
			}
			Jeremy_bond.S.currentPokemon = 0;
		}
		battle = false;
		isOption = false;
		isMove = false;
		BattleText.S.myAttack = false;
		BattleText.S.enemyAttack = false;
		BattleText.S.isWin = false;
		BattleText.S.isLost = false;
		BattleText.S.isWinFinish = false;
		BattleText.S.isLostFinish = false;
		BattleText.S.isStart = true;
		BattleText.S.isGo = false;
		BattleText.S.isWild = false;
		BattleText.S.isShowExp = false;
		BattleText.S.isNPC = false;
		BattleText.S.isNPCGo = false;
		BattleText.S.isLevelUp = false;
		BattleText.S.isEffective = false;
		BattleText.S.isCritical = false;
		BattleText.S.isEnemyEffective = false;
		BattleText.S.isEnemyCritical = false;
		BattleText.S.is281 = false;
		BattleText.S.isMary = false;
		BattleText.S.isDe = false;
		BattleText.S.isGib = false;
		BattleText.S.isMySegfault = false;
		BattleText.S.isEnemySegfault = false;
		BattleText.S.isMyTimeExceed = false;
		BattleText.S.isEnemyTimeExceed = false;

		ShowMyBall.S.gameObject.SetActive (true);
		NPCStart.S.gameObject.SetActive (true);
		EnemyPokemon.S.displayAttribute ();
		EnemyPokemon.S.gameObject.SetActive (true);
		Option.S.gameObject.SetActive(true);
		BattleText.S.gameObject.SetActive(true);
		Move.S.gameObject.SetActive (true);
		Battle.S.gameObject.SetActive(false);
		MyPokemon.S.segfault = 0;
		EnemyPokemon.S.C = 0;



	}
}
