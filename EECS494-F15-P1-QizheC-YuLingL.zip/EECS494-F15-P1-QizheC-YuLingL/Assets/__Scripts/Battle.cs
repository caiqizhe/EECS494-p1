﻿using UnityEngine;
using System.Collections;

public class Battle : MonoBehaviour {
	public static Battle S;
	// Use this for initialization
	void Awake(){
		S = this;
	}
	void Start () {
		gameObject.SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {
		if (!Main.S.battle) {
			GameObject soundObject = GameObject.Find ("leader_music");
			AudioSource audioSource = soundObject.GetComponent<AudioSource> ();
			GameObject soundObject1 = GameObject.Find ("valent_music");
			AudioSource audioSource1 = soundObject1.GetComponent<AudioSource> ();
			GameObject soundObject2 = GameObject.Find ("wild_music");
			AudioSource audioSource2 = soundObject2.GetComponent<AudioSource> ();
			audioSource2.Stop();
			audioSource.Stop();
			audioSource1.Play();
			Player.S.road = true;
			Main.S.exitBattle();
			Player.S.time = Time.time;
		}

	}

}
