﻿using UnityEngine;
using System.Collections;

public class Stats2 : MonoBehaviour {
	public static Stats2 S;
	public GameObject name;
	public GameObject nextlevel;
	public GameObject points;
	public GameObject picture;
	public GameObject pp1;
	public GameObject pp2;
	public GameObject pp3;
	public GameObject pp4;

	void Awake(){
		S = this;
	}
	// Use this for initialization
	void Start () {
		foreach (Transform  child in transform) {

		   if(child.gameObject.name == "Name"){
				name = child.gameObject;
			}

			else if(child.gameObject.name == "points"){
				points = child.gameObject;
			}
			else if(child.gameObject.name == "nextLevel"){
				nextlevel = child.gameObject;
			}
			else if(child.gameObject.name == "Picture"){
				picture = child.gameObject;
			}
			else if(child.gameObject.name == "PP1"){
				pp1 = child.gameObject;
			}
			else if(child.gameObject.name == "PP2"){
				pp2 = child.gameObject;
			}
			else if(child.gameObject.name == "PP3"){
				pp3 = child.gameObject;
			}
			else if(child.gameObject.name == "PP4"){
				pp4 = child.gameObject;
			}
			//gameObject.SetActive(false);
		}
	}
	
	// Update is called once per frame
	void Update () {
		name.GetComponent<GUIText>().text = Party.S.selectedP.name;
		points.GetComponent<GUIText>().text = Party.S.selectedP.curExp.ToString();
		/*if(Party.S.selectedP.levelType == "MF")
			nextlevel.GetComponent<GUIText>().text = (PokemonData.MF[Party.S.selectedP.level] - Party.S.selectedP.curExp).ToString() + "to :L" + (Party.S.selectedP.level + 1).ToString();
		else
			nextlevel.GetComponent<GUIText>().text = (PokemonData.MS[Party.S.selectedP.level] - Party.S.selectedP.curExp).ToString()  + "to :L" + (Party.S.selectedP.level + 1).ToString();*/

		picture.GetComponent<GUITexture>().texture = Resources.Load(Party.S.selectedP.path_norm) as Texture2D;

		if (Party.S.selectedP.Move1 != null) {
			foreach (Transform child in pp1.transform) {
				if (child.gameObject.name == "Name") {
					child.gameObject.GetComponent<GUIText> ().text = Party.S.selectedP.Move1;
				}
				if (child.gameObject.name == "currentPP") {
					child.gameObject.GetComponent<GUIText> ().text = Party.S.selectedP.Move1PP.ToString() + "/" + PokemonData.DictMove[Party.S.selectedP.Move1].MaxPP.ToString();
				}
			}
		}
		if (Party.S.selectedP.Move2 != null) {
			foreach (Transform child in pp2.transform) {
				if (child.gameObject.name == "Name") {
					child.gameObject.GetComponent<GUIText> ().text = Party.S.selectedP.Move2;
				}
				if (child.gameObject.name == "currentPP") {
					child.gameObject.GetComponent<GUIText> ().text = Party.S.selectedP.Move2PP.ToString() + "/" + PokemonData.DictMove[Party.S.selectedP.Move2].MaxPP.ToString();
				}
			}
		}
		if (Party.S.selectedP.Move3 != null) {
			foreach (Transform child in pp3.transform) {
				if (child.gameObject.name == "Name") {
					child.gameObject.GetComponent<GUIText> ().text = Party.S.selectedP.Move3;
				}
				if (child.gameObject.name == "currentPP") {
					child.gameObject.GetComponent<GUIText> ().text = Party.S.selectedP.Move3PP.ToString() + "/" + PokemonData.DictMove[Party.S.selectedP.Move3].MaxPP.ToString();
				}
			}
		}
		if (Party.S.selectedP.Move4 != null) {
			foreach (Transform child in pp4.transform) {
				if (child.gameObject.name == "Name") {
					child.gameObject.GetComponent<GUIText> ().text = Party.S.selectedP.Move4;
				}
				if (child.gameObject.name == "currentPP") {
					child.gameObject.GetComponent<GUIText> ().text = Party.S.selectedP.Move4PP.ToString() + "/" + PokemonData.DictMove[Party.S.selectedP.Move4].MaxPP.ToString();
				}
			}
		}
	}
}
