﻿using UnityEngine;
using System.Collections;

public class RedPicture : MonoBehaviour {
	public static RedPicture S;
	// Use this for initialization
	void Awake(){
		S = this;
	}
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
