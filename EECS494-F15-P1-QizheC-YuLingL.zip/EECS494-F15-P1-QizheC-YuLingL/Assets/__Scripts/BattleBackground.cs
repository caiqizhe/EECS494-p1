﻿using UnityEngine;
using System.Collections;

public class BattleBackground : MonoBehaviour {

	 static public BattleBackground S;
	// Use this for initialization
	void Awake(){
		S = this;
	}
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {

	}
}
