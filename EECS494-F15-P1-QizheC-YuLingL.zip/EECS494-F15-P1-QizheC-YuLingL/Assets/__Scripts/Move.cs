﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
public class Move : MonoBehaviour {

	public static Move S;
	public int activeItem;
	public int move1Index;
	public int move2Index;
	public int move3Index;
	public int move4Index;
	public int typeIndex;
	public int ppIndex;
	public GameObject selectButton;
	public bool hasMove1 = true;
	public bool hasMove2 = true;
	public bool hasMove3 = true;
	public bool hasMove4 = true;

	public List<GameObject> moveItems;
	// Use this for initialization
	void Awake(){
		S = this;
	}
	void Start () {
		activeItem = 0;
		foreach (Transform child in transform) {
			moveItems.Add(child.gameObject);
		}
		for (int i = 0; i < moveItems.Count; i++) {
			if (moveItems [i].name == "Move1") {
				move1Index = i;
				activeItem = i;
				print (moveItems [i].name);
			} else if (moveItems [i].name == "Move2") {
				move2Index = i;
				print (moveItems [i].name);

			} else if (moveItems [i].name == "Move3") {
				move3Index = i;
				print (moveItems [i].name);

			} else if (moveItems [i].name == "Move4") {
				move4Index = i;
				print (moveItems [i].name);

			} else if (moveItems [i].name == "Type") {
				typeIndex = i;
				print (moveItems [i].name);

			} else if (moveItems [i].name == "PP") {
				ppIndex = i;
				print (moveItems [i].name);

			}
		}
		//gameObject.SetActive (false);

	}
	
	// Update is called once per frame
	void Update () {
		if (Main.S.isMove == false)
			return;
		if (MyPokemon.current.Move1 == null) {
			hasMove1 = false;
			GUIText temp = moveItems[move1Index].GetComponent<GUIText>();
			temp.text = "-----";

		}
		else {
			GUIText temp = moveItems[move1Index].GetComponent<GUIText>();
			temp.text = MyPokemon.current.Move1;
			//print (MyPokemon.current.Move1);
			hasMove1 = true;
		}
		if (MyPokemon.current.Move2 == null) {
			hasMove2 = false;
			GUIText temp = moveItems[move2Index].GetComponent<GUIText>();
			temp.text = "-----";

		} else {
			hasMove2 = true;
			GUIText temp = moveItems[move2Index].GetComponent<GUIText>();
			temp.text = MyPokemon.current.Move2;

		}
		if (MyPokemon.current.Move3 == null) {
			hasMove3 = false;
			GUIText temp = moveItems[move3Index].GetComponent<GUIText>();
			temp.text = "-----";
		} else {
			hasMove3 = true;
			GUIText temp = moveItems[move3Index].GetComponent<GUIText>();
			temp.text = MyPokemon.current.Move3;
		}
		if (MyPokemon.current.Move4 == null) {
			hasMove4 = false;
			GUIText temp = moveItems[move4Index].GetComponent<GUIText>();
			temp.text = "-----";

		} else {
			hasMove4 = true;
			GUIText temp = moveItems[move4Index].GetComponent<GUIText>();
			temp.text = MyPokemon.current.Move4;
		}

		if (Main.S.isMove) {
			if(Input.GetKeyDown(KeyCode.A)){
				if(activeItem == move1Index && MyPokemon.current.Move1PP >= 0)
				{
					if(MyPokemon.current.Move1PP == 0)
						return;
					MyPokemon.current.Move1PP--;
				}
				else if(activeItem == move2Index && MyPokemon.current.Move2PP >= 0)
				{
					if(MyPokemon.current.Move2PP == 0)
						return;
					MyPokemon.current.Move2PP--;
				}
				else if(activeItem == move3Index && MyPokemon.current.Move3PP >= 0)
				{
					if(MyPokemon.current.Move3PP == 0)
						return;
					MyPokemon.current.Move3PP--;
				}
				else if(activeItem == move4Index && MyPokemon.current.Move4PP >= 0)
				{
					if(MyPokemon.current.Move4PP == 0)
						return;
					MyPokemon.current.Move4PP--;
				}
				Main.S.isMove = false;
				gameObject.SetActive(false);
				MyPokemon.currentMove = moveItems[activeItem].gameObject.GetComponent<GUIText>().text;
				print (MyPokemon.currentMove);
				BattleText.S.gameObject.SetActive(true);
				string text = MyPokemon.current.name + "\n" + "used " +  moveItems[activeItem].gameObject.GetComponent<GUIText>().text;
				if(MyPokemon.S.C > 1 && MyPokemon.currentMove != "C++")
					text += "\n C++ EFFECT DOUBLE DAMAGE";
				BattleText.S.displayText(text);

				BattleText.S.myAttack = true;
			}
			else if(Input.GetKeyDown(KeyCode.S)){
				Main.S.isMove = false;
				gameObject.SetActive(false);
				Main.S.isOption = true;
				Option.S.gameObject.SetActive(true);
			}
			else if (Input.GetKeyDown (KeyCode.DownArrow)) {
					MoveDownMenu();				
			} 
			else if (Input.GetKeyDown (KeyCode.UpArrow)) {
					MoveUpMenu();
			}

			GUIText typeText =  moveItems[typeIndex].gameObject.GetComponent<GUIText>();
			GUIText ppText = moveItems[ppIndex].gameObject.GetComponent<GUIText>();
			if(move1Index == activeItem){
				typeText.text = "TYPE/" + PokemonData.DictMove[MyPokemon.current.Move1].type;
				ppText.text = MyPokemon.current.Move1PP.ToString() + "/" + PokemonData.DictMove[MyPokemon.current.Move1].MaxPP.ToString();
			}
			else if(move2Index == activeItem){
				typeText.text = "TYPE/" + PokemonData.DictMove[MyPokemon.current.Move2].type;
				ppText.text = MyPokemon.current.Move2PP.ToString() + "/" + PokemonData.DictMove[MyPokemon.current.Move2].MaxPP.ToString();

				//print(MyPokemon.current.Move2PP.ToString());
			}
			else if(move3Index == activeItem){
				typeText.text = "TYPE/" + PokemonData.DictMove[MyPokemon.current.Move3].type;
				ppText.text = MyPokemon.current.Move3PP.ToString() + "/" + PokemonData.DictMove[MyPokemon.current.Move3].MaxPP.ToString();
			}
			else if(move4Index == activeItem){
				typeText.text = "TYPE/" + PokemonData.DictMove[MyPokemon.current.Move4].type;
				ppText.text = MyPokemon.current.Move4PP.ToString() + "/" + PokemonData.DictMove[MyPokemon.current.Move4].MaxPP.ToString();
			}
		}
	}
	public void MoveDownMenu(){
		if (move1Index == activeItem && hasMove2)
			activeItem = move2Index;
		else if (move2Index == activeItem && hasMove3)
			activeItem = move3Index;
		else if (move2Index == activeItem && hasMove3 == false)
			activeItem = move1Index;
		else if (move3Index == activeItem && hasMove4)
			activeItem = move4Index;
		else if (move3Index == activeItem && hasMove4 == false)
			activeItem = move1Index;
		else if (move4Index == activeItem)
			activeItem = move1Index;
		Vector3 position = selectButton.transform.position;
		print (moveItems[activeItem].transform.position.y);
		selectButton.transform.position = new Vector3 (position.x, moveItems[activeItem].transform.position.y -0.02f, position.z);
		
	}
	public void MoveUpMenu(){
		if (move1Index == activeItem && hasMove4) {
			activeItem = move4Index;
		}
		else if (move1Index == activeItem && hasMove3) {
			activeItem = move3Index;
		}
		else if (move1Index == activeItem && hasMove2) {
			activeItem = move2Index;
		}
		else if(move2Index == activeItem)
			activeItem = move1Index;
		else if(move3Index == activeItem)
			activeItem = move2Index;
		else if(move4Index == activeItem)
			activeItem = move3Index;
		Vector3 position = selectButton.transform.position;
		
		selectButton.transform.position = new Vector3 (position.x, moveItems [activeItem].transform.position.y -0.02f , position.z);
		
		
	}
}
