﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public enum selectItem{
	Bulbasaur,
	Charmander,
	Squirtle
}
public class SelectPokemon : MonoBehaviour {

	public static SelectPokemon S;
	
	public int activeItem;
	public List<GameObject> menuItems;
	void Awake(){
		S = this;
	}
	// Use this for initialization
	void Start () {
		bool first = true;
		activeItem = 0;
		foreach (Transform child in transform) {
			if(child.gameObject.name == "word"){
				foreach(Transform child2 in child){
					menuItems.Add (child2.gameObject);
					print(child2.gameObject.name);
				}
			}
		}
		menuItems = menuItems.OrderByDescending (m => m.transform.transform.position.y).ToList ();
		foreach (GameObject go in menuItems) {
			GUIText itemText = go.GetComponent<GUIText>();
			if(first) itemText.color = Color.red;
			first = false;
		}
		gameObject.SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {
		 if (!Main.S.isSelected) {
			if(Input.GetKeyDown(KeyCode.A)){
				switch(activeItem){
				case (int)selectItem.Bulbasaur:
					PokemonAttribute temp = new PokemonAttribute();
					temp.name = "Bulbasaur";
					temp.HP = 45;
					temp.atk = 49;
					temp.def = 49;
					temp.special = 65;
					temp.speed = 45;
					temp.level = 5;
					temp.Move1 = "Tackle";
					temp.Move1PP = PokemonData.DictMove[temp.Move1].MaxPP;
					temp.path_back = "bulbasaur-color-back";
					temp.path_norm = "bulbasaur-color-normal";
					temp.MaxHP = 45;
					MyPokemon.DictPokemon.Add(temp.name,temp);
					break;
				case (int)selectItem.Charmander:
					PokemonAttribute temp1 = new PokemonAttribute();
					temp1.name = "Charmander";
					temp1.HP = 39;
					temp1.atk = 52;
					temp1.def = 43;
					temp1.special = 60;
					temp1.speed = 65;
					temp1.level = 5;
					temp1.Move1 = "Scratch";
					temp1.Move1PP = PokemonData.DictMove[temp1.Move1].MaxPP;
					temp1.path_back = "charmander-color-back";
					temp1.path_norm = "charmander-color-normal";
					temp1.MaxHP = 39;
					MyPokemon.DictPokemon.Add(temp1.name,temp1);
					break;
				case (int)selectItem.Squirtle:
					PokemonAttribute temp2 = new PokemonAttribute();
					temp2.name = "Squirtle";
					temp2.HP = 44;
					temp2.atk = 48;
					temp2.def = 65;
					temp2.special = 50;
					temp2.speed = 43;
					temp2.level = 5;
					temp2.Move1 = "Tackle";
					temp2.Move1PP = PokemonData.DictMove[temp2.Move1].MaxPP;
					temp2.path_back = "squirtle-color-back";
					temp2.path_norm = "squirtle-color-normal";
					temp2.MaxHP = 44;
					MyPokemon.DictPokemon.Add(temp2.name,temp2);
					break;
				}
				SelectPokemon.S.gameObject.SetActive(false);
				Main.S.isSelected = true;
				Main.S.paused = false;
			}
		}
		if (Input.GetKeyDown (KeyCode.DownArrow)) {
			MoveDownMenu ();
		} else if (Input.GetKeyDown (KeyCode.UpArrow)) {
			MoveUpMenu();
		}
	}
	public void MoveDownMenu(){
		menuItems[activeItem].GetComponent<GUIText>().color = Color.black;
		activeItem = activeItem == menuItems.Count - 1 ? 0 : ++activeItem;
		menuItems [activeItem].GetComponent<GUIText> ().color = Color.red;
		
	}
	public void MoveUpMenu(){
		menuItems[activeItem].GetComponent<GUIText>().color = Color.black;
		activeItem = activeItem == 0 ? menuItems.Count - 1 : --activeItem;
		menuItems [activeItem].GetComponent<GUIText> ().color = Color.red;
		
	}
}