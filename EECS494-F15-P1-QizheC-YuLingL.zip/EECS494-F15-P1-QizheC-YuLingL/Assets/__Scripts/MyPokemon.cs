﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class MyPokemon : MonoBehaviour {
	public static Dictionary<string, PokemonAttribute> DictPokemon = new Dictionary<string, PokemonAttribute >();
	public static MyPokemon S;
	public static string currentMove;
	public List<GameObject> attributeItems;
	public static PokemonAttribute current;
	public int segfault = 0;
	public int C = 1;
	public int timeExceed = 0;
	void Awake(){
		S = this;
	}
	// Use this for initialization
	void Start () {
		if (DictPokemon.Count == 0)
			current = null;
		else 
			current = DictPokemon.Values.First ();
		foreach (Transform child in transform) {
			attributeItems.Add(child.gameObject);
		}
		print (attributeItems.Count);
	}
	
	// Update is called once per frame
	void Update () {
		if (DictPokemon.Count == 0)
			return;
		else if (current == null)
			current = MyPokemon.DictPokemon.Values.First ();
		if (Main.S.battle) {
			if(BattleText.S.isGo)
				gameObject.GetComponent<GUITexture> ().texture = Resources.Load("cloud") as Texture2D;
			else
				gameObject.GetComponent<GUITexture> ().texture = Resources.Load(current.path_back) as Texture2D;

			foreach(GameObject go in attributeItems){
				if(go.name == "Health"){
					go.GetComponent<GUIText>().text = current.HP.ToString() + "/" + current.MaxHP.ToString() ;
				}
				else if(go.name == "Name"){
					go.GetComponent<GUIText>().text = current.name;					
				}

			}
		}

	}
	public void Attack(){
		print (currentMove);
		MoveAttribute move = PokemonData.DictMove [currentMove];
		if (move.name == "C++")
			MyPokemon.S.C *= 2;
		else if (move.name == "segfault")
			EnemyPokemon.S.segfault += 2 * C;
		else if (move.name == "timeExceed")
			EnemyPokemon.S.timeExceed += 2 * C;
		print (move.name);
		if (move.power == 0)
			return;
		double damage = (double)((2 * MyPokemon.current.level + 10)* MyPokemon.current.atk * move.power / (double)EnemyPokemon.S.current.def) / 250.0;
		print (damage);
		double STAB = move.type == MyPokemon.current.type ? 1.5 : 1;
		double Type = PokemonData.Effect [(int)MyPokemon.current.type] [(int)EnemyPokemon.S.current.type];
		if (Type > 1)
			BattleText.S.isEffective = true;
		double critical = Random.Range (0, 2) > 0.5 ? 1.5 : 1;
		if(critical > 1)
			BattleText.S.isCritical = true;
		double random =  (double)Random.Range(0.85f, 1f);
		double modifier = STAB * Type * critical * random;
		damage = modifier * damage;
		print (damage);
		print (C);
		damage *= (double)C;
		print (damage);
		C = 1;
		if (timeExceed == 0) {
			EnemyPokemon.S.current.HP = EnemyPokemon.S.current.HP - (int)damage < 0 ? 0 : EnemyPokemon.S.current.HP - (int)damage;
		}
		else 
			MyPokemon.current.HP = MyPokemon.current.HP - (int)damage < 0 ? 0 : MyPokemon.current.HP - (int)damage;

		BattleText.S.isLost = true;
		foreach(KeyValuePair<string,PokemonAttribute> item in MyPokemon.DictPokemon){
			if(item.Value.HP != 0)
				BattleText.S.isLost = false;
		}

		if (BattleText.S.isMary && Mary_Lou_Dorf.S.currentPokemon < 2 && EnemyPokemon.S.current.HP <= 0) {
			
			Mary_Lou_Dorf.S.currentPokemon++;
			EnemyPokemon.S.current = Mary_Lou_Dorf.S.pokemonList[Mary_Lou_Dorf.S.currentPokemon];
			BattleText.S.isEnemySwitch = true;

			
		}
		else if (BattleText.S.isDe && Deorio.S.currentPokemon < 2 && EnemyPokemon.S.current.HP <= 0) {
			
			Deorio.S.currentPokemon++;
			EnemyPokemon.S.current = Deorio.S.pokemonList[Deorio.S.currentPokemon];
			BattleText.S.isEnemySwitch = true;
			
			
		}
		else if (BattleText.S.isGib && Jeremy_bond.S.currentPokemon < 2 && EnemyPokemon.S.current.HP <= 0) {
			
			Jeremy_bond.S.currentPokemon++;
			print (Jeremy_bond.S.currentPokemon);
			EnemyPokemon.S.current = Jeremy_bond.S.pokemonList[Jeremy_bond.S.currentPokemon];
			BattleText.S.isEnemySwitch = true;
			
			
		}

		else if(EnemyPokemon.S.current.HP <= 0)
			BattleText.S.isWin = true;
		//EnemyPokemon.S.Attack ();

	}
}
