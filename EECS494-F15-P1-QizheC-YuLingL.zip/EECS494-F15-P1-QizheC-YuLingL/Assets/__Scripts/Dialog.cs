﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Linq;
public class Dialog : MonoBehaviour {

	public static Dialog S;
	public int current = 0;
	public bool beginDialog = false;
	public List<string> background = new List<string>();
	void Awake(){
		S = this;
		string a = "The virus invades the Pokemon world and made some Pokemon get infected.\n ";
		background.Add(a);
		string a1 = "You, as a University of Michigan EECS student, is going to save the pokemon world.";
		background.Add (a1);
		string b  = "Aftr the invasion, the battle mechanism is completely changed. Some new moves are added.";
		background.Add (b);
		string c = "You can view them in your pokedex.";
		background.Add (c);
		string d = " There are three leaders that were good people but are affected by virus called \"EECS\". They are in the gym building.";
		background.Add (d);
		string e = "Beat them to save the world!";
		background.Add (e);
	}
	// Use this for initialization
	void Start () {
		HideDialogBox ();


	}
	public void ShowMessage(string message){
		S.gameObject.SetActive (true);
		Main.S.inDialog = true;
		GameObject dialogBox = transform.Find ("Text").gameObject;
		Text goText = dialogBox.GetComponent<Text>();
		goText.text = message;

	}
	// Update is called once per frame
	void Update () {
		if(Main.S.inDialog && (Input.GetKeyDown (KeyCode.S)|| Input.GetKeyDown(KeyCode.A)) && beginDialog){
			current++;
			if(current == background.Count)
			{
				beginDialog = false;
				HideDialogBox();
			}
			else {
				ShowMessage(background[current]);
			}
		}
		else if (Main.S.inDialog && Input.GetKeyDown (KeyCode.S)) {
			HideDialogBox ();

			if(Party.S.learnMode){
				Party.S.gameObject.SetActive(true);

			}
			else if (Main.S.talkeToOak == true && Main.S.isSelected == false) {
				SelectPokemon.S.gameObject.SetActive (true);
				Main.S.paused = true;

			} else if (Main.S.npc_move == true) {
				HideDialogBox ();
				if (BattleText.S.is281){
					Player.S.valent = false;
					Player.S.trainer = false;
					GameObject soundObject = GameObject.Find ("leader_music");
					AudioSource audioSource = soundObject.GetComponent<AudioSource> ();
					GameObject soundObject1 = GameObject.Find ("valent_music");
					AudioSource audioSource1 = soundObject1.GetComponent<AudioSource> ();
					audioSource1.Stop();
					audioSource.Play();
					Main.S.enterBattle("Trainer 281 wants to fight!",true);
					Main.S.npc_move = false;
					BattleText.S.is281 = false;
				}
				Main.S.npc_move = false;
			}
			else if(Mary_Lou_Dorf.S.isfight == true && Mary_Lou_Dorf.S.hasfight == false){
				
				BattleText.S.isMary = true;
				Mary_Lou_Dorf.S.hasfight = true;
				Player.S.valent = false;
				Player.S.trainer = false;
				GameObject soundObject = GameObject.Find ("leader_music");
				AudioSource audioSource = soundObject.GetComponent<AudioSource> ();
				GameObject soundObject1 = GameObject.Find ("valent_music");
				AudioSource audioSource1 = soundObject1.GetComponent<AudioSource> ();
				audioSource1.Stop();
				audioSource.Play();
				Item.S.items.RemoveAt(Item.S.items.Count - 1);
				Main.S.enterBattle("Mary wants to fight!",true);
			}
			else if(Deorio.S.isfight == true && Deorio.S.hasfight == false){
				BattleText.S.isDe = true;
				Deorio.S.hasfight = true;
				
				Player.S.valent = false;
				Player.S.trainer = false;
				GameObject soundObject = GameObject.Find ("leader_music");
				AudioSource audioSource = soundObject.GetComponent<AudioSource> ();
				GameObject soundObject1 = GameObject.Find ("valent_music");
				AudioSource audioSource1 = soundObject1.GetComponent<AudioSource> ();
				audioSource1.Stop();
				audioSource.Play();
				Item.S.items.RemoveAt(Item.S.items.Count - 1);
				Main.S.enterBattle("Deorio wants to fight!",true);
			}

			else if(Jeremy_bond.S.isfight == true && Jeremy_bond.S.hasfight == false){
				BattleText.S.isGib = true;
				Jeremy_bond.S.hasfight = true;
					Player.S.valent = false;
					Player.S.trainer = false;
					GameObject soundObject = GameObject.Find ("leader_music");
					AudioSource audioSource = soundObject.GetComponent<AudioSource> ();
					GameObject soundObject1 = GameObject.Find ("valent_music");
					AudioSource audioSource1 = soundObject1.GetComponent<AudioSource> ();
					audioSource1.Stop();
					audioSource.Play();
				Main.S.enterBattle("Jeremy wants to fight!",true);
			}

		}

	}
	public void HideDialogBox(){
//		Color noAlpha = GameObject.Find ("DialogBackground").GetComponent<GUITexture> ().color;
//		noAlpha.a = 0;
//		GameObject.Find ("DialogBackground").GetComponent<GUITexture> ().color = noAlpha;
		gameObject.SetActive (false);
		Main.S.inDialog = false;
	}
}
