﻿using UnityEngine;
using System.Collections;

public class enemyHealth : MonoBehaviour {

	public float maxBarLength;
	public float curBarLength;
	public GUITexture display;
	// Use this for initialization
	void Start () {
		display = gameObject.GetComponent<GUITexture> ();
		maxBarLength = display.pixelInset.width;
	}
	
	// Update is called once per frame
	void Update () {
		if (Main.S.battle) {
			curBarLength = ((float)EnemyPokemon.S.current.HP / EnemyPokemon.S.current.MaxHP) * maxBarLength;
			display.pixelInset = new Rect (display.pixelInset.x, display.pixelInset.y, curBarLength, display.pixelInset.height);
		}
	}
}
