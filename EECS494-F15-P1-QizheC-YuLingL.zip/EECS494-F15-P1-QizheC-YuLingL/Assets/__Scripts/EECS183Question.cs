﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class QuestionFormat {
	public string question;
	public List<string> choice = new List<string>();
	public int correct_index = 0;
}
public class EECS183Question : MonoBehaviour {
	public static EECS183Question S;
	public List<GameObject> answerItems;
	public List<QuestionFormat> questionList = new List<QuestionFormat> ();
	public GameObject question;
	public int activeItem = 0;
	public bool canChooseQuestion = false;
	public bool inQuestion = false;
	public int curQIndex = 0;

	Vector3 target = new Vector3(44, 96, 10);

	void Awake(){
		S = this;
		QuestionFormat q10 = new QuestionFormat ();
		q10.question = "Which of the following are valid variable declarations?";
		q10.choice.Add ("A)int 1f;");
		q10.choice.Add ("B)int if;");
		q10.choice.Add ("C)int if1;");
		q10.choice.Add ("D) (B) and (C)");
		q10.correct_index = 3;
		questionList.Add (q10);
		QuestionFormat q9 = new QuestionFormat ();
		q9.question = "Which of the following are valid function prototypes?";
		q9.choice.Add ("A)char void(double x);");
		q9.choice.Add ("B)int maximum(\"x\", y);");
		q9.choice.Add ("C)int calc(void x);");
		q9.choice.Add ("D)void squareRoot(double x);");
		q9.correct_index = 3;
		questionList.Add (q9);
		
		QuestionFormat q8 = new QuestionFormat ();
		q8.question = "Which of the following expressions is equivalent to: ( x > 0 && x <= 42 )";
		q8.choice.Add ("A) ( 0 < x <= 42 )");
		q8.choice.Add ("B) ( x !> 0 || x ! <= 42 )");
		q8.choice.Add ("C) ( x <= 0 && x > 42 )");
		q8.choice.Add ("D) none of the above");
		q8.correct_index = 3;
		questionList.Add (q8);

		QuestionFormat q7 = new  QuestionFormat ();
		q7.question = "Which of the following is a valid function prototype?";
		q7.choice.Add ("a) invert(double x);");
		q7.choice.Add ("b) int middle value(int x, int y, int z);");
		q7.choice.Add ("c) int calculate(void x);");
		q7.choice.Add ("d) void print();");
		q7.correct_index = 3;
		questionList.Add (q7);

		QuestionFormat q6 = new QuestionFormat ();
		q6.question = "Which of the following calls to the function process is valid,\n if process has the function prototype: void process(char y);?";
		q6.choice.Add ("a) process('A');");
		q6.choice.Add ("b) cout << process('A');");
		q6.choice.Add ("c) x = process('A');");
		q6.choice.Add ("d) all of the above");
		q6.correct_index = 0;
		questionList.Add (q6);

		QuestionFormat q5 = new QuestionFormat ();
		q5.question = "Which of the following is a valid function prototype?";
		q5.choice.Add ("a) void processArray(int a[ ][ ]);");
		q5.choice.Add ("b) void processArray(int a[100][ ]);");
		q5.choice.Add ("c) void processArray(int& a[ ][100]);");
		q5.choice.Add ("d) void processArray(int& a[100][ ]);");
		q5.correct_index = 3;
		questionList.Add (q5);

		QuestionFormat q4 = new QuestionFormat ();
		q4.question = "Which of the following statements prints 1 to the standard output?";
		q4.choice.Add ("a) cout<<(0.5>2/3);");
		q4.choice.Add ("b) cout<<(3<=0<=5);");
		q4.choice.Add ("c) intn=1234; while(n>9)n=n/10; cout<<n;");
		q4.choice.Add ("d) all of the above");
		q4.correct_index = 3;
		questionList.Add (q4);

		QuestionFormat q3= new QuestionFormat ();
		q3.question = "Which of the following statements prints 1 to the standard output?";
		q3.choice.Add ("a) cout<<(0.5>2/3);");
		q3.choice.Add ("b) cout<<(3<=0<=5);");
		q3.choice.Add ("c) intn=1234; while(n>9)n=n/10; cout<<n;");
		q3.choice.Add ("d) all of the above");
		q3.correct_index = 3;
		questionList.Add (q3);

		QuestionFormat q2 =new  QuestionFormat ();
		q2.question = "Which of the following statements prints 1 to the standard output?";
		q2.choice.Add ("a) cout<<(0.5>2/3);");
		q2.choice.Add ("b) cout<<(3<=0<=5);");
		q2.choice.Add ("c) intn=1234; while(n>9)n=n/10; cout<<n;");
		q2.choice.Add ("d) all of the above");
		q2.correct_index = 3;
		questionList.Add (q2);

		QuestionFormat q1 =new QuestionFormat ();
		q1.question = "Which of the following C++ expression evaluates to an even number?";
		q1.choice.Add ("a) 3 * 7 / 2 / 2");
		q1.choice.Add ("b) 7 * 3 / 2 / 2");
		q1.choice.Add ("c) 7 / 2 * 3 / 2");
		q1.choice.Add ("d) 7 / 2 / 2 * 3");
		q1.correct_index = 2;
		questionList.Add (q1);


	}
	// Use this for initialization
	void Start () {
		foreach (Transform child in transform) {
			if(child.gameObject.name[0] == 'A')
				answerItems.Add (child.gameObject);
			else if(child.gameObject.name == "Question")
				question = child.gameObject;

		}
		answerItems = answerItems.OrderByDescending (m => m.transform.transform.position.y).ToList ();
		GUIText itemText = answerItems[0].GetComponent<GUIText>();
		itemText.color = Color.red;
		print ("set false");
		S.gameObject.SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {
		for(int i = 0; i < answerItems.Count; i++)
		{
			answerItems[i].GetComponent<GUIText>().text = questionList[curQIndex].choice[i];
		}
		question.GetComponent<GUIText>().text = questionList[curQIndex].question;
		if (canChooseQuestion) {

			if (Input.GetKeyDown (KeyCode.S)) {
				gameObject.SetActive (false);
				inQuestion = false;
				canChooseQuestion = false;
			} else if (Input.GetKeyDown (KeyCode.A)) {
				if(activeItem == questionList[curQIndex].correct_index ){
					if(Player.S.transform.position.x == target.x && Player.S.transform.position.y == target.y && Player.S.hasMaryKey == false){
						Dialog.S.ShowMessage("You got the key!!!");
						Player.S.hasMaryKey = true;
						item key = new item();
						key.name = "Dorf Key";
						key.quantity = 1;
						Item.S.items.Add(key);
					}
					else if(Player.S.transform.position.y < target.y)
						Dialog.S.ShowMessage("Go up to find the key");
					else if(Player.S.transform.position.y < target.y)
						Dialog.S.ShowMessage("Go down to find the key");
					else if(Player.S.transform.position.x < target.x)
						Dialog.S.ShowMessage("Go right to find the key");
					else if(Player.S.transform.position.x > target.x)
						Dialog.S.ShowMessage("Go left to find the key");


				}
				else{
					Dialog.S.ShowMessage("Your answer choice is wrong!");
				}
				gameObject.SetActive (false);
				inQuestion = false;
				canChooseQuestion = false;
			}
			else if (Input.GetKeyDown (KeyCode.DownArrow)) {
				MoveDownMenu ();
			} else if (Input.GetKeyDown (KeyCode.UpArrow)) {
				MoveUpMenu ();
			}
		}
		if (inQuestion)
			canChooseQuestion = true;
	}
	public void MoveDownMenu(){
		answerItems[activeItem].GetComponent<GUIText>().color = Color.black;
		activeItem = activeItem == answerItems.Count - 1 ? 0 : ++activeItem;
		answerItems [activeItem].GetComponent<GUIText> ().color = Color.red;
		
	}
	public void MoveUpMenu(){
		answerItems[activeItem].GetComponent<GUIText>().color = Color.black;
		activeItem = activeItem == 0 ? answerItems.Count - 1 : --activeItem;
		answerItems [activeItem].GetComponent<GUIText> ().color = Color.red;
		
	}
}
