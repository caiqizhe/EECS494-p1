﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Option : MonoBehaviour {
	public static Option S;
	public int activeItem;
	public List<GameObject> menuItems;
	public int fightIndex;
	public int runIndex;
	public int switchIndex;
	public int packIndex;
	// Use this for initialization
	void Awake(){
		S = this;
	}
	void Start () {
 		activeItem = 0;
		foreach (Transform child in transform) {
			menuItems.Add (child.gameObject);
		}
		foreach (GameObject go in menuItems) {
			if(go.name == "Fight"){
				GUIText itemText = go.GetComponent<GUIText>();
				 itemText.color = Color.red;
			}
		}
		for (int i = 0; i < menuItems.Count; i++) {
			if(menuItems[i].name == "Fight"){
				GUIText itemText = menuItems[i].GetComponent<GUIText>();
				itemText.color = Color.red;
				activeItem = i;
				fightIndex = i;
			}
			else if(menuItems[i].name == "Pack")
				packIndex = i;
			else if(menuItems[i].name == "Switch")
				switchIndex = i;
			else if(menuItems[i].name == "Run")
				runIndex= i;
		}
		print ("option start");
		//gameObject.SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {

		if (Main.S.isOption) {
			if(Input.GetKeyDown(KeyCode.A)){
				Main.S.isOption = false;
				gameObject.SetActive(false);
				if(menuItems[activeItem].name == "Fight"){
					print (menuItems[activeItem].name);
					Move.S.gameObject.SetActive(true);
					Main.S.isMove = true;

				}
				else if(menuItems[activeItem].name == "Run"){
					if(BattleText.S.isNPC == false)
						Main.S.battle = false;
					else{
						BattleText.S.gameObject.SetActive(true);
						BattleText.S.displayText("Can not run when you fight with NPC!!!");
					}

					return;


				}
				else if(menuItems[activeItem].name == "Pack"){
					print (menuItems[activeItem].name);
					Item.S.gameObject.SetActive(true);
				}
				else if(menuItems[activeItem].name == "Switch"){
					print (menuItems[activeItem].name);
					Party.S.isInit = false;
					Party.S.gameObject.SetActive(true);

				}

			}
			else if (Input.GetKeyDown (KeyCode.DownArrow)) {
				if(menuItems[activeItem].name == "Fight" || menuItems[activeItem].name == "Switch"){
					MoveDownMenu(menuItems[activeItem].name);
				}

			} 
			else if (Input.GetKeyDown (KeyCode.UpArrow)) {
				if(menuItems[activeItem].name == "Pack" || menuItems[activeItem].name == "Run"){
					MoveUpMenu(menuItems[activeItem].name);
				}			
			}
			else if (Input.GetKeyDown (KeyCode.RightArrow)) {
				if(menuItems[activeItem].name == "Fight" || menuItems[activeItem].name == "Pack"){
					MoveRightMenu(menuItems[activeItem].name);
					print(menuItems[activeItem].name);
				}			
			}
			else if (Input.GetKeyDown (KeyCode.LeftArrow)) {
				if(menuItems[activeItem].name == "Switch" || menuItems[activeItem].name == "Run"){
					MoveLeftMenu(menuItems[activeItem].name);
				}			
			}

		}

	}
	public void MoveDownMenu(string current){
		menuItems[activeItem].GetComponent<GUIText>().color = Color.black;
		if(current == "Fight")
			activeItem = packIndex;
		else
			activeItem = runIndex;
		menuItems[activeItem].GetComponent<GUIText> ().color = Color.red;
		
	}
	public void MoveUpMenu(string current){
		menuItems[activeItem].GetComponent<GUIText>().color = Color.black;
		if(current == "Pack")
			activeItem = fightIndex;
		else
			activeItem = switchIndex;
		menuItems[activeItem].GetComponent<GUIText> ().color = Color.red;
		
	}
	public void MoveLeftMenu(string current){
		menuItems[activeItem].GetComponent<GUIText>().color = Color.black;
		if(current == "Switch")
			activeItem = fightIndex;
		else
			activeItem = packIndex;
		menuItems[activeItem].GetComponent<GUIText> ().color = Color.red;
		
	}
	public void MoveRightMenu(string current){
		menuItems[activeItem].GetComponent<GUIText>().color = Color.black;
		if (current == "Fight")
			activeItem = switchIndex;
		else
			activeItem = runIndex;
		menuItems[activeItem].GetComponent<GUIText> ().color = Color.red;
		
	}
}
