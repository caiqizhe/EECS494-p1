﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public enum Direction{
	down,
	left,
	up,
	right
}

public class Player : MonoBehaviour {
	
	public static Player S;
	public int money = 0;
	public float moveSpeed;
	public int tileSize;

	public Sprite		upSprite;
	public Sprite		downSprite;
	public Sprite		leftSprite;
	public Sprite		rightSprite;

	public SpriteRenderer sprend;
	public bool ___________;

	public RaycastHit	hitInfo;

	public bool moving = false;
	public Vector3 targetPos;
	public Direction direction;
	public Vector3 moveVec;
	public float time;
	
	public bool road = true;
	public bool pc =true;
	public bool wild = true;
	public bool trainer = true;
	public bool valent =true;
	public bool eecs183key = false;

	public bool hasMaryKey = false;
	public int DeOrioKey = 0;
	public List<GameObject> ballList = new List<GameObject>();

	void Awake(){
		S = this;
	}
	void Start(){
		sprend = gameObject.GetComponent<SpriteRenderer> ();
		time = Time.time;
	}
	 public Rigidbody rigidbody {
		get{ return gameObject.GetComponent<Rigidbody> ();}
	}
	
	public Vector3 pos {
		get{ return transform.position;}
		set{ transform.position = value;}
	}
	
	void FixedUpdate() {
		if (transform.position.x > 220 && transform.position.x < 255 && transform.position.y > 140 && transform.position.y < 160 && road) {
			road = false;
			valent = true;
			GameObject soundObject = GameObject.Find ("valent_music");
			AudioSource audioSource = soundObject.GetComponent<AudioSource> ();
			GameObject soundObject1 = GameObject.Find ("road_music");
			AudioSource audioSource1 = soundObject1.GetComponent<AudioSource> ();
			audioSource.Stop();
			audioSource1.Play ();
		} else if (transform.position.x >= 255 && transform.position.x < 280 && transform.position.y > 140 && transform.position.y < 180 && valent) {
			GameObject soundObject = GameObject.Find ("valent_music");
			AudioSource audioSource = soundObject.GetComponent<AudioSource> ();
			GameObject soundObject1 = GameObject.Find ("road_music");
			AudioSource audioSource1 = soundObject1.GetComponent<AudioSource> ();
			if (!pc){
				GameObject soundObject4 = GameObject.Find ("pc_music");
				AudioSource audioSource4 = soundObject4.GetComponent<AudioSource> ();
				audioSource4.Stop();
				pc = true;
			}
			if (!wild){
				wild = true;
				GameObject soundObject3 = GameObject.Find ("wild_music");
				AudioSource audioSource3 = soundObject3.GetComponent<AudioSource> ();
				audioSource3.Stop();
			}
			audioSource1.Stop();
			audioSource.Play ();
			valent = false;
			road = true;
		} else if (transform.position.y > 70 && transform.position.y < 80 && transform.position.x < 10 && transform.position.x > -5 && pc) {
			GameObject soundObject = GameObject.Find ("pc_music");
			AudioSource audioSource = soundObject.GetComponent<AudioSource> ();
			GameObject soundObject1 = GameObject.Find ("valent_music");
			AudioSource audioSource1 = soundObject1.GetComponent<AudioSource> ();
			audioSource1.Stop();
			audioSource.Play ();
			pc = false;
			valent = true;
		}
		if (!moving && !Main.S.inDialog && !Main.S.paused && !Main.S.battle && !Party.S.learnMode && !EECS183Question.S.inQuestion) {
			if( Input.GetKeyDown(KeyCode.A)){
				CheckForAction();
			}
			if (Physics.Raycast(GetRay(), out hitInfo, 1.2f, GetLayerMask(new string[]{"Grass"})) && MyPokemon.DictPokemon.Count == 0){
				print("can't enter grass without a pokemon!");
				if(transform.position.x == 68 && transform.position.y > 69){
					transform.position = new Vector3(68.0f, 69.0f, -0.01f);
				}
				else if (transform.position.x == 69 && transform.position.y > 69){
					transform.position = new Vector3(69.0f, 69.0f, -0.01f);
				}
				moveVec = Vector3.down;
				direction = Direction.down;
				sprend.sprite = downSprite;
				Dialog.S.gameObject.SetActive(true);
				Dialog.S.ShowMessage("You can't enter the grass without a Pokemon! Please go to Prof.Oak's Room to pick a Pokemon first!");
			}
			if (Input.GetKey (KeyCode.RightArrow)) {
				moveVec = Vector3.right;
				direction = Direction.right;
				sprend.sprite = rightSprite;
				moving = true;
			} else if (Input.GetKey (KeyCode.LeftArrow)) {
				moveVec = Vector3.left;
				direction = Direction.left;
				sprend.sprite = leftSprite;
				moving = true;
			} else if (Input.GetKey (KeyCode.UpArrow)) {
				moveVec = Vector3.up;
				direction = Direction.up;
				sprend.sprite = upSprite;
				moving = true;
			} else if (Input.GetKey (KeyCode.DownArrow)) {
				moveVec = Vector3.down;
				direction = Direction.down;
				sprend.sprite = downSprite;
				moving = true;
			} else {
				moveVec = Vector3.zero;
				moving = false;
			}
			if(Physics.Raycast(GetRay(), out hitInfo, 1f, GetLayerMask(new string[]{"Immovable", "NPC","ball","Mary","Deorio","Jeremy","PC"}))){
				moveVec = Vector3.zero;
				moving = false;
			}
			if(Physics.Raycast(GetRay(), out hitInfo, 1f, GetLayerMask(new string[]{"Ledge"}))){
				if (direction == Direction.up){
					moveVec = Vector3.zero;
					moving = false;
				}
			}
			targetPos = pos + moveVec;
			
		} 
		else {
			print (3);
			if ((targetPos - pos).magnitude < moveSpeed * Time.fixedDeltaTime) {
				pos = targetPos;
				moving = false;
			} 
			else {
				pos += (targetPos - pos).normalized * moveSpeed * Time.fixedDeltaTime;
			}
			if(Physics.Raycast(GetRay(), out hitInfo, 0.05f, GetLayerMask(new string[]{"Grass"}))){
				print (2);
				if(Random.value < 0.1 && MyPokemon.DictPokemon.Count > 0 && !Main.S.paused){
					if (wild){
						valent = false;
						wild = false;
						GameObject soundObject = GameObject.Find ("wild_music");
						AudioSource audioSource = soundObject.GetComponent<AudioSource> ();
						GameObject soundObject1 = GameObject.Find ("valent_music");
						AudioSource audioSource1 = soundObject1.GetComponent<AudioSource> ();
						audioSource1.Stop();
						audioSource.Play ();
					}
					wild = true;
					print (2);
					Main.S.enterBattle("Wild Pokemon\nAppeared!", false);
				}
			}
		}
		print (Physics.Raycast (GetRay (), out hitInfo, 0.05f, GetLayerMask (new string[]{"Grass"})));
		print (Physics.Raycast(GetRay(), out hitInfo, 0.05f, GetLayerMask(new string[]{"Immovable"})));

	}
	public void CheckForAction(){
		if (transform.position.x == -1 && transform.position.y == 74 && direction == Direction.up) {
			if (Physics.Raycast (GetRay (), out hitInfo, 2f, GetLayerMask (new string[]{"NPC"}))){
				NPC npc = hitInfo.collider.gameObject.GetComponent<NPC>();
				npc.FacePlayer(direction);
				npc.PlayDialog();
				foreach(KeyValuePair<string, PokemonAttribute> entry in MyPokemon.DictPokemon)
				{
					entry.Value.HP = entry.Value.MaxHP;
					// do something with entry.Value or entry.Key
				}

			}
		} else if (Physics.Raycast (GetRay (), out hitInfo, 1f, GetLayerMask (new string[]{"NPC"}))) {
			print ("1");
			NPC npc = hitInfo.collider.gameObject.GetComponent<NPC>();
			npc.FacePlayer(direction);
			npc.PlayDialog();
		}
		else if (Physics.Raycast (GetRay (), out hitInfo, 1f, GetLayerMask (new string[]{"Mary"}))) {
			Mary_Lou_Dorf npc = hitInfo.collider.gameObject.GetComponent<Mary_Lou_Dorf>();
			if(Player.S.hasMaryKey == false){
				Dialog.S.gameObject.SetActive(true);
				Dialog.S.ShowMessage("You didn't find the key!");
			}
			else if(npc.isfight == false){
				npc.isfight = true;
				npc.FacePlayer(direction);
				Dialog.S.gameObject.SetActive(true);
				Dialog.S.ShowMessage("Beat me if you can pass 183");
				npc.FacePlayer(direction);
			}else{
				npc.FacePlayer(direction);
				npc.PlayDialog();
			}
		}
		else if (Physics.Raycast (GetRay (), out hitInfo, 1f, GetLayerMask (new string[]{"Deorio"}))) {
			Deorio npc = hitInfo.collider.gameObject.GetComponent<Deorio>();
			if(Player.S.DeOrioKey < 3)
			{
				Dialog.S.gameObject.SetActive(true);
				Dialog.S.ShowMessage("You didn't find all three keys!");
			}
			else if(npc.isfight == false){
				npc.isfight = true;
				npc.FacePlayer(direction);
				Dialog.S.gameObject.SetActive(true);
				Dialog.S.ShowMessage("All chicken is good chicken!!");
				npc.FacePlayer(direction);

			}else{
				npc.FacePlayer(direction);
				npc.PlayDialog();
			}
		}
		else if (Physics.Raycast (GetRay (), out hitInfo, 1f, GetLayerMask (new string[]{"PC"}))) {
			EECS183Question.S.inQuestion = true;
			EECS183Question.S.gameObject.SetActive(true);
			EECS183Question.S.curQIndex = Random.Range(0,10);
		}
		else if (Physics.Raycast (GetRay (), out hitInfo, 1f, GetLayerMask (new string[]{"Jeremy"}))) {
			Jeremy_bond npc = hitInfo.collider.gameObject.GetComponent<Jeremy_bond>();
			if(npc.isfight == false){
				npc.isfight = true;
				npc.FacePlayer(direction);
				Dialog.S.gameObject.SetActive(true);
				Dialog.S.ShowMessage("Let's test your game!!");
				npc.FacePlayer(direction);

			}else{
			npc.FacePlayer(direction);
			npc.PlayDialog();
			}
		}
		else if (Physics.Raycast (GetRay (), out hitInfo, 1f, GetLayerMask (new string[]{"ball"}))) {
			GameObject ball = hitInfo.collider.gameObject;
			ball.SetActive(false);
			Dialog.S.ShowMessage("Get one key!!");
			if(DeOrioKey == 0){
				item item1 = new item();
				item1.name = "DeOrio eggs";
				item1.quantity = 1;
				Item.S.items.Add(item1);
			}
			else{
				Item.S.items[2].quantity ++;
			}
			DeOrioKey++;
			ballList.Add(ball);

			
		}	
	}
	Ray GetRay(){
		switch(direction){
		case Direction.down:
			return new Ray(pos, Vector3.down);
		case Direction.left:
			return new Ray(pos, Vector3.left);
		case Direction.right:
			return new Ray(pos, Vector3.right);
		case Direction.up:
			return new Ray(pos, Vector3.up);
		default:
			return new Ray();
		}
	}
	int GetLayerMask(string[] layerNames){
		int layerMask  = 0;
		foreach(string layer in layerNames){
			layerMask = layerMask | (1 << LayerMask.NameToLayer(layer));
		}

		return layerMask;
	}
	public void MoveThroughDoor(Vector3 doorLoc){
		if (doorLoc.z <= 0)
			doorLoc.z = transform.position.z;
		moving = false;
		moveVec = Vector3.zero;
		transform.position = doorLoc;
	}
}