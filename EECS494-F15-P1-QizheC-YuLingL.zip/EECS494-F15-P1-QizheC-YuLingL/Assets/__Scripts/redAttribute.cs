﻿using UnityEngine;
using System.Collections;

public class redAttribute : MonoBehaviour {
	public static redAttribute S;
	void Awake(){
		S = this;
	}
	// Use this for initialization
	void Start () {
		S.gameObject.SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {
		foreach (Transform child in transform)
			child.gameObject.GetComponent<GUIText> ().text = Player.S.money.ToString();
		if (Input.GetKeyDown (KeyCode.A)) {
			gameObject.SetActive (false);
			Menu.S.isSelected = false;
		}
	}
}
