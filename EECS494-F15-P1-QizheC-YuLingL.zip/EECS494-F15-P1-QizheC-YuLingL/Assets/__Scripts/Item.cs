﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class item{
	public string name;
	public int quantity;
}
public class Item : MonoBehaviour {
	public static Item S;
	public List<item> items = new List<item>();
	public int activeItem;
	public List<GameObject> menuItems;
	public bool isUseOrToss = false;
	// Use this for initialization
	void Awake(){
		S = this;
	}
	void Start () {
		foreach (Transform child in transform) {
			menuItems.Add (child.gameObject);
		}
		menuItems = menuItems.OrderByDescending (m => m.transform.transform.position.y).ToList ();

		item item1 = new item ();
		item1.name = "MasterPokeBall";
		item1.quantity = 5;
		item item2 = new item ();
		item2.name = "Potion";
		item2.quantity = 10;
		items.Add (item1);
		items.Add (item2);
		activeItem = 0;
		menuItems [activeItem].GetComponent<GUIText> ().color = Color.red;
		gameObject.SetActive (false);

	}
	
	// Update is called once per frame
	void Update () {
		if (isUseOrToss == false) {
			for (int i = 0; i < items.Count; i++) {
				menuItems [i].GetComponent<GUIText> ().text = items [i].name;
				foreach (Transform child in menuItems[i].transform) {
					child.gameObject.GetComponent<GUIText> ().text = items [i].quantity.ToString ();
				}
			}
			print (items.Count);
			for (int i = items.Count; i < menuItems.Count; i++) {
				menuItems [i].GetComponent<GUIText> ().text = "";
				foreach (Transform child in menuItems[i].transform) {
					child.gameObject.GetComponent<GUIText> ().text = "";
				}		
			}


			if (Input.GetKeyDown (KeyCode.A)) {
				if(activeItem == 2){
					return;
				}
				isUseOrToss = true;
				useOrtoss.S.gameObject.SetActive(true);
			} else if (Input.GetKeyDown (KeyCode.DownArrow)) {
				MoveDownMenu ();
			} else if (Input.GetKeyDown (KeyCode.UpArrow)) {
				MoveUpMenu ();
			}  else if (Input.GetKeyDown (KeyCode.S)) {
				gameObject.SetActive (false);
				if(Main.S.paused)
					Menu.S.isSelected = false;
				else if(Main.S.battle){
					Main.S.isOption = true;
					Option.S.gameObject.SetActive(true);
				}
			}
		}
	}
	public void MoveDownMenu(){
		print ("movedown");
		menuItems[activeItem].GetComponent<GUIText>().color = Color.black;
		activeItem = activeItem == items.Count - 1 ? 0 : ++activeItem;
		menuItems [activeItem].GetComponent<GUIText> ().color = Color.red;
		
	}
	public void MoveUpMenu(){
		menuItems[activeItem].GetComponent<GUIText>().color = Color.black;
		activeItem = activeItem == 0 ? items.Count - 1 : --activeItem;
		menuItems [activeItem].GetComponent<GUIText> ().color = Color.red;
		
	}
}
