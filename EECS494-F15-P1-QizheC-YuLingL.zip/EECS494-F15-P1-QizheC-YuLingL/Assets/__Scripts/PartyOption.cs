﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
public class PartyOption : MonoBehaviour {
	public static PartyOption S;
	public List<GameObject> menuItems;
	public int activeItem;
	public bool isPartyOption = false;
	public bool isShowStats = false;
	void Awake(){
		S = this;
	}
	// Use this for initialization
	void Start () {
		activeItem = 0;
		foreach (Transform child in transform) {
			menuItems.Add (child.gameObject);
		}
		menuItems = menuItems.OrderByDescending (m => m.transform.transform.position.y).ToList ();
		bool first = true;
		foreach (GameObject go in menuItems) {
			GUIText itemText = go.GetComponent<GUIText>();
			if(first) itemText.color = Color.red;
			first = false;
		}
		//gameObject.SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {
		if (isShowStats == false && Main.S.inDialog == false) {
			if (Input.GetKeyDown (KeyCode.A)) {
				if (menuItems [activeItem].name == "Stats") {
					print (1);
					pokemonStats.S.gameObject.SetActive(true);
					pokemonStats.S.isStats1 = true;
					Stats2.S.gameObject.SetActive(false);
					isShowStats = true;
				} else if (menuItems [activeItem].name == "Select") {
					MyPokemon.current = Party.S.selectedP;
					gameObject.SetActive (false);
					isPartyOption = false;
					if(Main.S.battle){
						print ("s");
						BattleText.S.gameObject.SetActive(true);
						BattleText.S.displayText("Go !!" + MyPokemon.current.name);
					}
					else if(Party.S.learnMode){
						if(Party.S.selectedP.Move4 != null){
							Dialog.S.ShowMessage("the move is full!!");
							return;
						}
						else{
							if(Party.S.selectedP.Move2 == null){
								Party.S.selectedP.Move2 = Party.S.learnMove;
								Party.S.selectedP.Move2PP = PokemonData.DictMove[Party.S.selectedP.Move2].MaxPP;
							}
							else if(Party.S.selectedP.Move3 == null){
								Party.S.selectedP.Move3 = Party.S.learnMove;
								Party.S.selectedP.Move3PP = PokemonData.DictMove[Party.S.selectedP.Move2].MaxPP;
							}
							else if(Party.S.selectedP.Move4 == null){
								Party.S.selectedP.Move4 = Party.S.learnMove;
								Party.S.selectedP.Move4PP = PokemonData.DictMove[Party.S.selectedP.Move2].MaxPP;
							}
							Party.S.learnMode = false;
							Dialog.S.ShowMessage("Congradulation!!  " + Party.S.selectedP.name + " learn  " + Party.S.learnMove + "\n And Your pokemons are all healthy!");

						}
					}
					else
						Menu.S.isSelected = false;
					Party.S.gameObject.SetActive(false);


				} else if (menuItems [activeItem].name == "Cancel") {
					gameObject.SetActive (false);
					isPartyOption = false;

				}
			} else if (Input.GetKeyDown (KeyCode.DownArrow)) {
				MoveDownMenu ();

			} else if (Input.GetKeyDown (KeyCode.UpArrow)) {
				MoveUpMenu ();
			}
		}
	}
	public void MoveDownMenu(){
		menuItems[activeItem].GetComponent<GUIText>().color = Color.black;
		activeItem = activeItem == menuItems.Count - 1 ? 0 : ++activeItem;
		menuItems [activeItem].GetComponent<GUIText> ().color = Color.red;
		
	}
	public void MoveUpMenu(){
		menuItems[activeItem].GetComponent<GUIText>().color = Color.black;
		activeItem = activeItem == 0 ? menuItems.Count - 1 : --activeItem;
		menuItems [activeItem].GetComponent<GUIText> ().color = Color.red;
		
	}
}
