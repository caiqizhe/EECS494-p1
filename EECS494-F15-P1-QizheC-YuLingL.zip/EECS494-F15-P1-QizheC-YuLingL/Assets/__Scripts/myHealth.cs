﻿using UnityEngine;
using System.Collections;

public class myHealth: MonoBehaviour {
	public float maxBarLength;
	public float curBarLength;
	public GUITexture display;
	// Use this for initialization
	void Start () {
		display = gameObject.GetComponent<GUITexture> ();
		maxBarLength = display.pixelInset.width;
		print (maxBarLength);
	}
	
	// Update is called once per frame
	void Update () {
		if (Main.S.battle) {
			curBarLength = ((float)MyPokemon.current.HP / MyPokemon.current.MaxHP) * maxBarLength;
			display.pixelInset = new Rect (display.pixelInset.x, display.pixelInset.y, curBarLength, display.pixelInset.height);
		}
	}
}
