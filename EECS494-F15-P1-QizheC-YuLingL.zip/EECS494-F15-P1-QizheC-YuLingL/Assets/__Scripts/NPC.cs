﻿using UnityEngine;
using System.Collections;
using System;
public class NPC : MonoBehaviour {

	public string 	speech;

	public Sprite   upSprite;
	public Sprite   downSprite;
	public Sprite   leftSprite;
	public Sprite   rightSprite;
	public Direction direction;
	public RaycastHit	hitInfo;
	public SpriteRenderer 	sprend;
	public bool fight = false;
	public static GameObject red;
	public static GameObject npc1;
	public static GameObject npc2;
	float move_time = 0f;
	float grass_time = 0f;
	float eecs281time = 0f;
	public static float battle1 = 0f;
	public static float battle2 = 0f;
	public static float battle3 = 0f;
	public static float battle4 = 0f;
	public static float battle5 = 0f;

	public static bool if_talk = false;
	bool movingToLoc = false;
	float movingToStartTime;
	float movingToDuration;
	Vector3 p0, p1, v1, v2,v1end, v2end;
	public Transform p1Trans;

	// Use this for initialization
	void Start () {
		sprend = gameObject.GetComponent<SpriteRenderer> ();
	}
	public Vector3 pos {
		get{ return transform.position;}
		set{ transform.position = value;}
	}
	public void PlayDialog(){
		print (speech);
		Dialog.S.gameObject.SetActive (true);
		Dialog.S.ShowMessage (speech);
		if (gameObject.tag == "Oak" && Main.S.talkeToOak == false) {
			Main.S.talkeToOak = true;
		}
	}
	public void FacePlayer(Direction playerDir){
		switch(playerDir){
		case  Direction.down:
			sprend.sprite = upSprite;
			break;
		case  Direction.right:
			sprend.sprite = leftSprite;
			break;
		case  Direction.left:
			sprend.sprite = rightSprite;
			break;
		case  Direction.up:
			sprend.sprite = downSprite;
			break;
		}
	}
	// Update is called once per frame
	void Update () {
		if (movingToLoc) {
			MoveToLoc ();
			return;
		}
		if (gameObject.tag == "Grass_NPC" && fight == false && MyPokemon.DictPokemon.Count > 0 && grass_time != 1) {
			if (Main.S.canEnterBattle () && Physics.Raycast (GetRay (), out hitInfo, 10f, GetLayerMask (new string[]{"Player"}))) {
				red = GameObject.FindWithTag ("Player");
				p0 = this.transform.position;
				p1Trans = red.transform;
				movingToStartTime = Time.time;
				movingToDuration = 0.25f * (p1Trans.position - p0).magnitude;
				movingToLoc = true;
				Main.S.paused = true;
				grass_time++;
				if_talk = true;
			}
		} else if (gameObject.tag == "Move_NPC" && fight == false && MyPokemon.DictPokemon.Count > 0 && move_time != 1) {
			if (Main.S.canEnterBattle () && Physics.Raycast (GetRay (), out hitInfo, 4f, GetLayerMask (new string[]{"Player"}))) {
				red = GameObject.FindWithTag ("Player");
				p0 = this.transform.position;
				p1Trans = red.transform;
				movingToStartTime = Time.time;
				movingToDuration = 0.25f * (p1Trans.position - p0).magnitude;
				movingToLoc = true;
				Main.S.paused = true;
				move_time++;
			}
		} else if (gameObject.tag == "281NPC" && fight == false && MyPokemon.DictPokemon.Count > 0 && eecs281time != 1) {
			if (Main.S.canEnterBattle () && Physics.Raycast (GetRay (), out hitInfo, 2f, GetLayerMask (new string[]{"Player"}))) {
				red = GameObject.FindWithTag ("Player");
				p0 = this.transform.position;
				p1Trans = red.transform;
				movingToStartTime = Time.time;
				movingToDuration = 0.25f * (p1Trans.position - p0).magnitude;
				movingToLoc = true;
				Main.S.paused = true;
				eecs281time++;
			}
		} else if (gameObject.tag == "281Battle" && fight == false && MyPokemon.DictPokemon.Count > 0 && battle1 != 1) {
			if (Main.S.canEnterBattle () && Physics.Raycast (GetRay (), out hitInfo, 10f, GetLayerMask (new string[]{"Player"}))) {
				red = GameObject.FindWithTag ("Player");
				p0 = this.transform.position;
				p1Trans = red.transform;
				movingToStartTime = Time.time;
				movingToDuration = 0.25f * (p1Trans.position - p0).magnitude;
				movingToLoc = true;
				Main.S.paused = true;
				battle1++;
			}
		} else if (gameObject.tag == "281Battle1" && fight == false && MyPokemon.DictPokemon.Count > 0 && battle2 != 1) {
			if (Main.S.canEnterBattle () && Physics.Raycast (GetRay (), out hitInfo, 10f, GetLayerMask (new string[]{"Player"}))) {
				print(6666666);
				red = GameObject.FindWithTag ("Player");
				p0 = this.transform.position;
				p1Trans = red.transform;
				movingToStartTime = Time.time;
				movingToDuration = 0.25f * (p1Trans.position - p0).magnitude;
				movingToLoc = true;
				Main.S.paused = true;
				battle2++;
			}
		} else if (gameObject.tag == "281Battle2" && fight == false && MyPokemon.DictPokemon.Count > 0 && battle3 != 1) {
			if (Main.S.canEnterBattle () && Physics.Raycast (GetRay (), out hitInfo, 10f, GetLayerMask (new string[]{"Player"}))) {
				red = GameObject.FindWithTag ("Player");
				p0 = this.transform.position;
				p1Trans = red.transform;
				movingToStartTime = Time.time;
				movingToDuration = 0.25f * (p1Trans.position - p0).magnitude;
				movingToLoc = true;
				Main.S.paused = true;
				battle3++;
			}
		} else if (gameObject.tag == "281Battle3" && fight == false && MyPokemon.DictPokemon.Count > 0 && battle4 != 1) {
			if (Main.S.canEnterBattle () && Physics.Raycast (GetRay (), out hitInfo, 10f, GetLayerMask (new string[]{"Player"}))) {
				red = GameObject.FindWithTag ("Player");
				p0 = this.transform.position;
				p1Trans = red.transform;
				movingToStartTime = Time.time;
				movingToDuration = 0.25f * (p1Trans.position - p0).magnitude;
				movingToLoc = true;
				Main.S.paused = true;
				battle4++;
			}
		} else if (gameObject.tag == "281Battle4" && fight == false && MyPokemon.DictPokemon.Count > 0 && battle5 != 1) {
			if (Main.S.canEnterBattle () && Physics.Raycast (GetRay (), out hitInfo, 10f, GetLayerMask (new string[]{"Player"}))) {
				red = GameObject.FindWithTag ("Player");
				p0 = this.transform.position;
				p1Trans = red.transform;
				movingToStartTime = Time.time;
				movingToDuration = 0.25f * (p1Trans.position - p0).magnitude;
				movingToLoc = true;
				Main.S.paused = true;
				battle5++;
			}
		}
	} 



	

	void MoveToLoc() {
		float u = (Time.time - movingToStartTime) / movingToDuration;
		if (Math.Abs(p1Trans.position.x - transform.position.x) <= 1 && Math.Abs(p1Trans.position.y - transform.position.y) <= 1) {
			u = 1;
			//fight = true;
			Main.S.npc_move = true;
			Dialog.S.gameObject.SetActive(true);
			if (if_talk && gameObject.tag == "Move_NPC"){
				Dialog.S.ShowMessage("Good luck trainer! Please save the Pokemon world!");
			} else if (if_talk == false && gameObject.tag == "Move_NPC"){
				Dialog.S.ShowMessage("Please go back to the cave and talk to the man at the gate, he will give you some master balls to catch the Pokemon you need!");
			} else if (gameObject.tag == "Grass_NPC"){
				Dialog.S.ShowMessage("Wait! Before you go into the cave, I will give you 5 master balls!");
			} else if (gameObject.tag == "281NPC"){
					Dialog.S.ShowMessage("Deorio's Chicken hatched some eggs but there is are three eggs that are missing. Try to find eggs in the trashbinand then Deorio will accept your challenge!");
			} else if (gameObject.tag == "281Battle"){
				Dialog.S.ShowMessage("This is room1. Let's battle!");
				BattleText.S.is281 = true;
			} else if (gameObject.tag == "281Battle1"){
				Dialog.S.ShowMessage("This is room2. Let's battle!");
				BattleText.S.is281 = true;
			} else if (gameObject.tag == "281Battle2"){
				Dialog.S.ShowMessage("This is room3. Let's battle!");
				BattleText.S.is281 = true;
			} else if (gameObject.tag == "281Battle3"){
				Dialog.S.ShowMessage("This is room4. Let's battle!");
				BattleText.S.is281 = true;
			} else if (gameObject.tag == "281Battle4"){
				Dialog.S.ShowMessage("This is room5. Let's battle!");
				BattleText.S.is281 = true;
			}
			movingToLoc = false;
			Main.S.paused = false;
			return;
		}
		transform.position = (1 - u) * p0 + u * p1Trans.position;
	}

	Ray GetRay(){
		switch(direction){

		case Direction.down:
			return new Ray(pos, Vector3.down);
		case Direction.left:
			return new Ray(pos, Vector3.left);
		case Direction.right:
			return new Ray(pos, Vector3.right);
		case Direction.up:
			return new Ray(pos, Vector3.up);
		default:
			return new Ray();
		}
	}
	int GetLayerMask(string[] layerNames){
		int layerMask  = 0;
		foreach(string layer in layerNames){
			layerMask = layerMask | (1 << LayerMask.NameToLayer(layer));
		}
		
		return layerMask;
	}

}
