﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
public class useOrtoss : MonoBehaviour {
	public static useOrtoss S;
	public int activeItem;
	public List<GameObject> menuItems;
	// Use this for initialization
	void Awake(){
		S = this;
	}
	void Start () {
		foreach (Transform child in transform) {
			menuItems.Add (child.gameObject);
		}
		menuItems = menuItems.OrderByDescending (m => m.transform.transform.position.y).ToList ();
		activeItem = 0;
		menuItems [activeItem].GetComponent<GUIText> ().color = Color.red;
		gameObject.SetActive (false);

	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.A)) {
			print (menuItems [activeItem].name);
			if (menuItems [activeItem].name == "Use") {
				print (Item.S.menuItems [activeItem].GetComponent<GUIText>().text.ToString());
				if (Item.S.menuItems [Item.S.activeItem].GetComponent<GUIText>().text.ToString() == "Potion") {
					Party.S.gameObject.SetActive (true);
					gameObject.SetActive (false);
					Item.S.items [Item.S.activeItem].quantity--;
					if(Item.S.items[Item.S.activeItem].quantity == 0){
						Item.S.items.RemoveAt(Item.S.activeItem);
						Item.S.activeItem = 0;
						Item.S.menuItems[Item.S.activeItem].GetComponent<GUIText> ().color = Color.red;

					}
				}
				else{
					if(Main.S.battle){
						if(BattleText.S.isNPC){
							gameObject.SetActive(false);
							Item.S.isUseOrToss = false;
							Item.S.gameObject.SetActive(false);
							BattleText.S.displayText("Can not use pokeball when fight with NPC");
							BattleText.S.gameObject.SetActive(true);
							return;
						}
						gameObject.SetActive (false);
						Item.S.items [Item.S.activeItem].quantity--;
						Item.S.gameObject.SetActive(false);
						Item.S.isUseOrToss = false;
						BattleText.S.isCaughtTry = true;
						BattleText.S.displayText("Try Catch pokemon");
						if(Item.S.items[Item.S.activeItem].quantity == 0){
							Item.S.items.RemoveAt(Item.S.activeItem);
							Item.S.activeItem = 0;
							Item.S.menuItems[Item.S.activeItem].GetComponent<GUIText> ().color = Color.red;
							
						}
					}
				}

			} else {
				if(Main.S.battle){
					gameObject.SetActive(false);
					Item.S.isUseOrToss = false;
					Item.S.gameObject.SetActive(false);
					BattleText.S.displayText("Can not toss item during fight");
					BattleText.S.gameObject.SetActive(true);
					return;
				}
				Item.S.items [Item.S.activeItem].quantity--;
				if(Item.S.items[Item.S.activeItem].quantity == 0){
					Item.S.items.RemoveAt(Item.S.activeItem);
					Item.S.activeItem = 0;
					Item.S.menuItems[Item.S.activeItem].GetComponent<GUIText> ().color = Color.red;
					print ("red");

				}
				gameObject.SetActive (false);
				Item.S.isUseOrToss = false;
			}
	
		} else if (Input.GetKeyDown (KeyCode.DownArrow)) {
			MoveDownMenu ();
		} else if (Input.GetKeyDown (KeyCode.UpArrow)) {
			MoveUpMenu ();
		} else if (Input.GetKeyDown (KeyCode.S)) {
			gameObject.SetActive (false);
			Item.S.isUseOrToss = false;
		}
	
	}
	public void MoveDownMenu(){
		print ("movedown");
		menuItems[activeItem].GetComponent<GUIText>().color = Color.black;
		activeItem = activeItem == menuItems.Count - 1 ? 0 : ++activeItem;
		menuItems [activeItem].GetComponent<GUIText> ().color = Color.red;
		
	}
	public void MoveUpMenu(){
		menuItems[activeItem].GetComponent<GUIText>().color = Color.black;
		activeItem = activeItem == 0 ? menuItems.Count - 1 : --activeItem;
		menuItems [activeItem].GetComponent<GUIText> ().color = Color.red;
		
	}
}
