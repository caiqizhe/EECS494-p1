﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
public enum pokemonItem{
	pokemon1,
	pokemon2,
	pokemon3,
	pokemon4,
	pokemon5,
	pokemon6
}
public class Party : MonoBehaviour {

	public int activeItem;
	public int maxActive;
	public static Party S;
	public GameObject selectButton;
	public GameObject textBackground;
	public List<GameObject> pokemonItems;
	public GameObject option;
	public PokemonAttribute selectedP;
	public bool isInit = false;
	public string learnMove = "";
	public bool learnMode = false;
	public bool canLearn = false;
	void Awake(){
		S = this;
	}

	void Start(){
		activeItem = 0;
		maxActive = 0;
		foreach (Transform child in transform) {
			if(child.gameObject.name[0] == 'p'){
				pokemonItems.Add(child.gameObject);
			}
			else if(child.gameObject.name[0] == 'S'){
				selectButton = child.gameObject;
			}
			else if(child.gameObject.name[0] == 't')
				textBackground = child.gameObject;
			else if(child.gameObject.name[0] == 'o'){
				option = child.gameObject;
				option.SetActive(false);
			}
		}
		pokemonItems = pokemonItems.OrderByDescending (m => m.transform.transform.position.y).ToList ();
		int index = 0;
		foreach(KeyValuePair<string, PokemonAttribute> entry in MyPokemon.DictPokemon)
		{
			foreach(Transform child in pokemonItems[index].transform){
				if(child.gameObject.name == "Level"){
					child.gameObject.GetComponent<GUIText>().text = entry.Value.level.ToString();
				}
				else if(child.gameObject.name == "Name"){
					child.gameObject.GetComponent<GUIText>().text = entry.Value.name;
				}
				else if(child.gameObject.name == "Health"){
					child.gameObject.GetComponent<GUIText>().text = entry.Value.HP.ToString() + "/" + entry.Value.MaxHP.ToString();
				}
				else if(child.gameObject.name == "Picture"){
					child.gameObject.GetComponent<GUITexture> ().texture = Resources.Load(entry.Value.path_norm) as Texture2D;
				}
			}
			// do something with entry.Value or entry.Key
			pokemonItems[index].SetActive(true);
			index++;
		}
		maxActive = index - 1;
		for (int i = index; i < pokemonItems.Count; i++) {
			pokemonItems[i].SetActive(false);
		}
		if (maxActive < 0)
			selectButton.SetActive (false);
		gameObject.SetActive (false);

	}

	void Update(){
		if (PartyOption.S.isPartyOption == false && Main.S.inDialog == false) {
			int index = 0;
			PartyOption.S.gameObject.SetActive(false);
			foreach (KeyValuePair<string, PokemonAttribute> entry in MyPokemon.DictPokemon) {
				foreach (Transform child in pokemonItems[index].transform) {
					if (child.gameObject.name == "Level") {
						child.gameObject.GetComponent<GUIText> ().text = entry.Value.level.ToString ();
					} else if (child.gameObject.name == "Name") {
						child.gameObject.GetComponent<GUIText> ().text = entry.Value.name;
					} else if (child.gameObject.name == "Health") {
						child.gameObject.GetComponent<GUIText> ().text = entry.Value.HP.ToString () + "/" + entry.Value.MaxHP.ToString();
					} else if (child.gameObject.name == "Picture") {
						child.gameObject.GetComponent<GUITexture> ().texture = Resources.Load (entry.Value.path_norm) as Texture2D;
					}
				}
				// do something with entry.Value or entry.Key
				pokemonItems [index].SetActive (true);
				if(entry.Value.name == MyPokemon.current.name && isInit == false){
					activeItem = index;
					
					Vector3 position = selectButton.transform.position;
					
					selectButton.transform.position = new Vector3 (position.x, pokemonItems [activeItem].transform.position.y, position.z);
					isInit = true;
				}
				index++;
			}
			maxActive = index - 1;
			for (int i = index; i < pokemonItems.Count; i++) {
				pokemonItems [i].SetActive (false);
			}

			if (maxActive < 0) {
				selectButton.SetActive (false);
				if (Input.GetKeyDown (KeyCode.A)) {
					if (Main.S.paused)
						Menu.S.isSelected = false;
					if (Main.S.battle) {
						print ("s");
						Main.S.isOption = true;
						Option.S.gameObject.SetActive (true);
					}
					gameObject.SetActive (false);

				}
			} else {
				if (selectButton.activeSelf == false)
					selectButton.SetActive (true);
				if (Input.GetKeyDown (KeyCode.A)) {
					string name = "";
					foreach (Transform child in pokemonItems[activeItem].transform) {
						if (child.gameObject.name == "Name") {
							name = child.gameObject.GetComponent<GUIText> ().text;
						}

					}
					if(Item.S.isUseOrToss){
						MyPokemon.DictPokemon[name].HP = MyPokemon.DictPokemon[name].MaxHP;					
						gameObject.SetActive(false);
						Item.S.isUseOrToss = false;
						Item.S.gameObject.SetActive(false);
						if(Main.S.battle == false){
							Menu.S.isSelected = false;
							return;
						}
						BattleText.S.gameObject.SetActive(true);
						BattleText.S.displayText("Heal the pokemon!!");
						return;
					}
					selectedP = MyPokemon.DictPokemon [name];
					PartyOption.S.gameObject.SetActive (true);
					PartyOption.S.isPartyOption = true;
					/*if(Main.S.paused)
					Menu.S.isSelected = false;
				if(Main.S.battle){
					print ("s");
					Main.S.isOption = true;
					Option.S.gameObject.SetActive(true);
				}
					gameObject.SetActive (false);*/
				} else if (Input.GetKeyDown (KeyCode.DownArrow)) {
					MoveDownMenu ();
				} else if (Input.GetKeyDown (KeyCode.UpArrow)) {
					MoveUpMenu ();
				}
				else if(Input.GetKeyDown(KeyCode.S)){
					if(Main.S.paused)
						Menu.S.isSelected = false;
					if(Main.S.battle){
						print ("s");
						BattleText.S.gameObject.SetActive(true);
						BattleText.S.displayText("Go !!" + MyPokemon.current.name);
					}
					if(Party.S.learnMode)
						Party.S.learnMode = false;
					gameObject.SetActive (false);
				}
			}
		}
	}

	public void MoveDownMenu(){
		activeItem = activeItem == maxActive ? 0 : ++activeItem;
		Vector3 position = selectButton.transform.position;

		selectButton.transform.position = new Vector3 (position.x, pokemonItems [activeItem].transform.position.y, position.z);
		
	}
	public void MoveUpMenu(){
		activeItem = activeItem == 0 ? maxActive : --activeItem;
		Vector3 position = selectButton.transform.position;

		selectButton.transform.position = new Vector3 (position.x, pokemonItems [activeItem].transform.position.y, position.z);

		
	}

}
