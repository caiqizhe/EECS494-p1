﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public enum Type{
	NORMAL,
	FIRE,
	WATER,
	ELECTRIC,
	GRASS

}
public enum Category{
	PHYSICAL,
	SPECIAL,
	AFFECTED

}
public class MoveAttribute{
	public string name;
	public Category category;
	public int power;
	public int accuracy;
	public  Type type;
	public int MaxPP;
}
public class PokemonAttribute{
	public string name;
	public Type type;
	public int HP;
	public int MaxHP;
	public int atk;
	public int def;
	public int special;
	public int speed;
	public int level;
	public string levelType;
	public int curExp = 0;
	public string path_norm = "_Art_";
	public string path_back = "";
	public string Move1 = null;
	public int Move1PP;
	public string Move2 = null;
	public int Move2PP;
	public string Move3 = null;
	public int Move3PP;
	public string Move4 = null;
	public int Move4PP;
}
public class PokemonData{
	public static Dictionary<int, int> MF = new Dictionary<int,int>();
	public static Dictionary<int, int> MS = new Dictionary<int,int>();
	public static double[][] Effect = new double[][]{
		new double[]{1,1,1,1,1},
		new double[]{1,0.5,0.5,1,2},
		new double[]{1,2,0.5,1,0.5},
		new double[]{1,1,2,0.5, 0.5},
		new double[]{1,1,2,0.5,0.5}

	};
	public static Dictionary<string, MoveAttribute> DictMove = new Dictionary<string, MoveAttribute>();
	public static  void start () {
		MF.Add (1, 8);
		MF.Add (2, 19);
		MF.Add (3, 37);
		MF.Add (4, 61);
		MF.Add (5, 91);
		MF.Add (6, 127);
		MF.Add (7, 169);
		MF.Add (8, 217);
		MF.Add (9, 271);
		MF.Add (10, 331);
		MF.Add (11, 397);
		MF.Add (12, 469);
		MF.Add (13, 547);
		MF.Add (14, 631);
		MF.Add (15, 721);

		MS.Add (1, 9);
		MS.Add (2, 48);
		MS.Add (3, 39);
		MS.Add (4, 39);
		MS.Add (5, 44);
		MS.Add (6, 57);
		MS.Add (7, 78);
		MS.Add (8, 105);
		MS.Add (9, 141);
		MS.Add (10, 182);
		MS.Add (11, 231);
		MS.Add (12, 288);
		MS.Add (13, 351);
		MS.Add (14, 423);
		MS.Add (15, 500);


		MoveAttribute DragonBreath = new MoveAttribute ();
		
		DragonBreath.type = Type.NORMAL;
		DragonBreath.name = "Dragon Breath";
		DragonBreath.accuracy = 100;
		DragonBreath.power = 60;
		DragonBreath.MaxPP = 20;
		DragonBreath.category = Category.SPECIAL;
		PokemonData.DictMove.Add (DragonBreath.name, DragonBreath);

		MoveAttribute WaterPulse = new MoveAttribute ();

		WaterPulse.type = Type.NORMAL;
		WaterPulse.name = "Water Pulse";
		WaterPulse.accuracy = 100;
		WaterPulse.power = 60;
		WaterPulse.MaxPP = 20;
		WaterPulse.category = Category.SPECIAL;
		PokemonData.DictMove.Add (WaterPulse.name, WaterPulse);


		MoveAttribute algorithm = new MoveAttribute ();
		
		algorithm.type = Type.NORMAL;
		algorithm.name = "algorithm";
		algorithm.accuracy = 100;
		algorithm.power = 0;
		algorithm.MaxPP = 2;
		algorithm.category = Category.AFFECTED;
		PokemonData.DictMove.Add (algorithm.name, algorithm);

		MoveAttribute timeOut = new MoveAttribute ();
		
		timeOut.type = Type.NORMAL;
		timeOut.name = "timeExceed";
		timeOut.accuracy = 100;
		timeOut.power = 0;
		timeOut.MaxPP = 2;
		timeOut.category = Category.AFFECTED;
		PokemonData.DictMove.Add (timeOut.name, timeOut);

		MoveAttribute segfault = new MoveAttribute ();
		
		segfault.type = Type.NORMAL;
		segfault.name = "segfault";
		segfault.accuracy = 100;
		segfault.power = 0;
		segfault.MaxPP = 2;
		segfault.category = Category.AFFECTED;
		PokemonData.DictMove.Add (segfault.name, segfault);

		MoveAttribute debug = new MoveAttribute ();
		
		debug.type = Type.NORMAL;
		debug.name = "debug";
		debug.accuracy = 100;
		debug.power = 0;
		debug.MaxPP = 2;
		debug.category = Category.AFFECTED;
		PokemonData.DictMove.Add (debug.name, debug);

		MoveAttribute unity = new MoveAttribute ();
		
		unity.type = Type.NORMAL;
		unity.name = "Unity";
		unity.accuracy = 100;
		unity.power = 60;
		unity.MaxPP = 35;
		unity.category = Category.AFFECTED;
		PokemonData.DictMove.Add (unity.name, unity);

		MoveAttribute C = new MoveAttribute ();
		C.type = Type.NORMAL;
		C.name = "C++";
		C.accuracy = 100;
		C.power = 0;
		C.MaxPP = 2;
		C.category = Category.PHYSICAL;
		PokemonData.DictMove.Add (C.name, C);



		MoveAttribute python = new MoveAttribute ();
		python.type = Type.NORMAL;
		python.name = "Python";
		python.accuracy = 100;
		python.power = 60;
		python.MaxPP = 35;
		python.category = Category.PHYSICAL;
		PokemonData.DictMove.Add (python.name, python);

		MoveAttribute fire = new MoveAttribute ();
		fire.type = Type.NORMAL;
		fire.name = "Fire Blast";
		fire.accuracy = 100;
		fire.power = 50;
		fire.MaxPP = 35;
		fire.category = Category.PHYSICAL;
		PokemonData.DictMove.Add (fire.name, fire);
		MoveAttribute temp1 = new MoveAttribute ();
		temp1.type = Type.NORMAL;
		temp1.name = "Tackle";
		temp1.accuracy = 100;
		temp1.power = 50;
		temp1.MaxPP = 35;
		temp1.category = Category.PHYSICAL;
		PokemonData.DictMove.Add (temp1.name, temp1);
		
		MoveAttribute temp2 = new MoveAttribute ();
		temp2.type = Type.NORMAL;
		temp2.name = "Hidden Power";
		temp2.accuracy = 100;
		temp2.power = 30;
		temp2.MaxPP = 39;
		temp2.category = Category.PHYSICAL;
		PokemonData.DictMove.Add (temp2.name, temp2);

		MoveAttribute temp3 = new MoveAttribute ();
		temp3.type = Type.WATER;
		temp3.name = "Hydro Bump";
		temp3.accuracy = 80;
		temp3.power = 30;
		temp3.MaxPP = 20;
		temp3.category = Category.SPECIAL;
		PokemonData.DictMove.Add (temp3.name, temp3);

		MoveAttribute temp4 = new MoveAttribute ();
		temp4.type = Type.FIRE;
		temp4.name = "Fire Fang";
		temp4.accuracy = 30;
		temp4.power = 65;
		temp4.MaxPP = 24;
		temp4.category = Category.PHYSICAL;
		PokemonData.DictMove.Add (temp4.name, temp4);

		MoveAttribute temp5 = new MoveAttribute ();
		temp5.type = Type.GRASS;
		temp5.name = "Solar Beam";
		temp5.accuracy = 100;
		temp5.power = 30;
		temp5.MaxPP = 16;
		temp5.category = Category.SPECIAL;
		PokemonData.DictMove.Add (temp5.name, temp5);





	


		PokemonAttribute Mewtwo = new PokemonAttribute ();
		Mewtwo.name = "Mewtwo";
		Mewtwo.type = Type.NORMAL;
		Mewtwo.atk = 103;
		Mewtwo.def = 90;
		Mewtwo.special = 143;
		Mewtwo.speed = 121;
		Mewtwo.HP = 106;
		Mewtwo.MaxHP = 106;
		Mewtwo.level = 50;
		Mewtwo.Move1 = "Fire Fang";
		Mewtwo.Move1PP = DictMove ["Fire Fang"].MaxPP;
		Mewtwo.path_norm = "mewtwo-color-normal";
		Mewtwo.path_back = "mewtwo-color-back";
		Mewtwo.curExp = 0;
		//Reshiram.levelType = "MS";
		EnemyPokemon.EnemyList.Add (Mewtwo);

		PokemonAttribute Reshiram = new PokemonAttribute ();
		Reshiram.name = "Reshiram";
		Reshiram.type = Type.NORMAL;
		Reshiram.atk = 112;
		Reshiram.def = 94;
		Reshiram.special = 139;
		Reshiram.speed = 85;
		Reshiram.HP = 160;
		Reshiram.MaxHP = 160;
		Reshiram.level = 50;
		Reshiram.Move1 = "Fire Fang";
		Reshiram.Move1PP = DictMove ["Fire Fang"].MaxPP;
		Reshiram.path_norm = "reshiram-color-normal";
		Reshiram.path_back = "reshiram-color-back";
		Reshiram.curExp = 0;
		//Reshiram.levelType = "MS";
		EnemyPokemon.EnemyList.Add (Reshiram);

		PokemonAttribute Groudon = new PokemonAttribute ();
		Groudon.name = "Groudon";
		Groudon.type = Type.NORMAL;
		Groudon.atk = 139;
		Groudon.def = 130;
		Groudon.special = 94;
		Groudon.speed = 85;
		Groudon.HP = 160;
		Groudon.MaxHP = 160;
		Groudon.level = 56;
		Groudon.Move1 = "Solar Beam";
		Groudon.curExp = 0;
		Groudon.Move1PP = DictMove ["Solar Beam"].MaxPP;;
		Groudon.path_norm = "groudon-color-normal";
		Groudon.path_back = "groudon-color-back";
		EnemyPokemon.EnemyList.Add (Groudon);

		PokemonAttribute Lugia = new PokemonAttribute ();
		Lugia.name = "Lugia";
		Lugia.type = Type.NORMAL;
		Lugia.atk = 85;
		Lugia.def = 121;
		Lugia.special = 103;
		Lugia.speed = 85;
		Lugia.HP = 166;
		Lugia.MaxHP = 166;
		Lugia.level = 56;
		Lugia.Move1 = "Hydro Bump";
		Lugia.curExp = 0;
		Lugia.Move1PP = DictMove ["Hydro Bump"].MaxPP;;
		Lugia.path_norm = "lugia-color-normal";
		Lugia.path_back = "lugia-color-back";
		EnemyPokemon.EnemyList.Add (Lugia);



		PokemonAttribute temp6 = new PokemonAttribute();
		temp6.name = "Charizard";
		temp6.HP = 138;
		temp6.atk = 80;
		temp6.def = 74;
		temp6.special = 102;
		temp6.speed = 94;
		temp6.level = 50;
		temp6.Move1 = "Fire Blast";
		temp6.Move1PP = PokemonData.DictMove[temp6.Move1].MaxPP;
		temp6.path_back = "charizard-color-back";
		temp6.path_norm = "charizard-color-normal";
		temp6.MaxHP = 138;
		temp6.Move2 = "timeExceed";
		temp6.Move2PP = PokemonData.DictMove[temp6.Move2].MaxPP;
		/*temp6.Move3 = "timeExceed";
		temp6.Move3PP = PokemonData.DictMove[temp6.Move3].MaxPP;
		temp6.Move4 = "segfault";
		temp6.Move4PP = PokemonData.DictMove[temp6.Move4].MaxPP;*/

		MyPokemon.DictPokemon.Add(temp6.name,temp6);
		MyPokemon.current = MyPokemon.DictPokemon["Charizard"];
	}

}
