﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class ShowMyBall : MonoBehaviour {
	public static ShowMyBall S;
	public List<GameObject> ballItems = new List<GameObject>();
	void Awake(){
		S = this;
	}
	// Use this for initialization
	void Start () {
		foreach (Transform child in transform) {
			if(child.gameObject.name[0] == 'B')
				ballItems.Add(child.gameObject);
		}
		ballItems = ballItems.OrderBy(m => m.transform.transform.position.x).ToList ();

	}
	
	// Update is called once per frame
	void Update () {
		if (Main.S.battle) {
			int count = MyPokemon.DictPokemon.Count;
			for(int i = 0; i < count; i++)
			{
				ballItems[i].gameObject.GetComponent<GUITexture>().texture = Resources.Load("fullball") as Texture2D;
			}
			for(int i = count; i < 6; i++)
			{
				ballItems[i].gameObject.GetComponent<GUITexture>().texture = Resources.Load("emptyball") as Texture2D;
			}
		}
	}
}
