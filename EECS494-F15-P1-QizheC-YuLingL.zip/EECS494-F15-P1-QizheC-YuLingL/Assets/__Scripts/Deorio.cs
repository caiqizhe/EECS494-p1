﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;

public class Deorio : MonoBehaviour {
	
	public string 	speech;
	
	public Sprite   upSprite;
	public Sprite   downSprite;
	public Sprite   leftSprite;
	public Sprite   rightSprite;
	public Direction direction;
	public RaycastHit	hitInfo;
	public SpriteRenderer 	sprend;
	public bool fight = false;
	public static GameObject red;
	public static GameObject npc1;
	public static GameObject npc2;
	public bool isfight = false;
	public bool hasfight = false;
//	float move_time = 0f;

//	bool movingToLoc = false;
//	float movingToStartTime;
//	float movingToDuration;
//	Vector3 p0, p1, v1, v2,v1end, v2end;
	public Transform p1Trans;

	public List<PokemonAttribute> pokemonList;
	public int currentPokemon = 0;
	public static Deorio S;

	void Awake(){
		S = this;
	}
	
	// Use this for initialization
	void Start () {
		sprend = gameObject.GetComponent<SpriteRenderer> ();
		pokemonList = new List<PokemonAttribute> ();
		print (32);
		
		PokemonAttribute Mewtwo = new PokemonAttribute ();
		Mewtwo.name = "Mewtwo";
		Mewtwo.type = Type.NORMAL;
		Mewtwo.atk = 103;
		Mewtwo.def = 90;
		Mewtwo.special = 143;
		Mewtwo.speed = 121;
		Mewtwo.HP = 106;
		Mewtwo.MaxHP = 106;
		Mewtwo.level = 50;
		Mewtwo.Move1 = "Fire Fang";
		Mewtwo.Move1PP = PokemonData.DictMove ["Fire Fang"].MaxPP;
		Mewtwo.path_norm = "mewtwo-color-normal";
		Mewtwo.path_back = "mewtwo-color-back";
		Mewtwo.curExp = 0;
		pokemonList.Add (Mewtwo);
		
		PokemonAttribute Reshiram = new PokemonAttribute ();
		Reshiram.name = "Reshiram";
		Reshiram.type = Type.NORMAL;
		Reshiram.atk = 112;
		Reshiram.def = 94;
		Reshiram.special = 139;
		Reshiram.speed = 85;
		Reshiram.HP = 160;
		Reshiram.MaxHP = 160;
		Reshiram.level = 50;
		Reshiram.Move1 = "Fire Fang";
		Reshiram.Move1PP = PokemonData.DictMove ["Fire Fang"].MaxPP;
		Reshiram.path_norm = "reshiram-color-normal";
		Reshiram.path_back = "reshiram-color-back";
		Reshiram.curExp = 0;
		
		
		pokemonList.Add (Reshiram);

		PokemonAttribute Giratina = new PokemonAttribute ();
		Giratina.name = "Giratina";
		Giratina.type = Type.NORMAL;
		Giratina.atk = 100;
		Giratina.def = 90;
		Giratina.special = 150;
		Giratina.speed = 140;
		Giratina.HP = 400;
		Giratina.MaxHP = 400;
		Giratina.level = 50;
		Giratina.Move1 = "Dragon Breath";
		Giratina.Move1PP = PokemonData.DictMove ["Dragon Breath"].MaxPP;
		Giratina.path_norm = "giratina-color-normal";
		Giratina.path_back = "giratina-color-back";
		Giratina.Move2 = "segfault";
		Giratina.Move2PP = 2;
		
		Giratina.Move3 = "timeExceed";
		Giratina.Move2PP = 2;
		Giratina.Move4 = "debug";
		Giratina.Move4PP = 2;

		pokemonList.Add (Giratina);
		print (pokemonList.Count);
	}
	public Vector3 pos {
		get{ return transform.position;}
		set{ transform.position = value;}
	}
	public void PlayDialog(){
		print (speech);
		Dialog.S.gameObject.SetActive (true);
		Dialog.S.ShowMessage (speech);
		if (gameObject.tag == "Oak" && Main.S.talkeToOak == false) {
			Main.S.talkeToOak = true;
		}
	}
	public void FacePlayer(Direction playerDir){
		switch(playerDir){
		case  Direction.down:
			sprend.sprite = upSprite;
			break;
		case  Direction.right:
			sprend.sprite = leftSprite;
			break;
		case  Direction.left:
			sprend.sprite = rightSprite;
			break;
		case  Direction.up:
			sprend.sprite = downSprite;
			break;
		}
	}
	// Update is called once per frame
	void Update () {

	}
	
	

	
	Ray GetRay(){
		switch(direction){
			
		case Direction.down:
			return new Ray(pos, Vector3.down);
		case Direction.left:
			return new Ray(pos, Vector3.left);
		case Direction.right:
			return new Ray(pos, Vector3.right);
		case Direction.up:
			return new Ray(pos, Vector3.up);
		default:
			return new Ray();
		}
	}
	int GetLayerMask(string[] layerNames){
		int layerMask  = 0;
		foreach(string layer in layerNames){
			layerMask = layerMask | (1 << LayerMask.NameToLayer(layer));
		}
		
		return layerMask;
	}
	
}
