﻿using UnityEngine;
using System.Collections;

public class pokemonStats : MonoBehaviour {
	public static pokemonStats S;
	public bool isStats1 = false;
	public bool isStats2 = false;

	void Awake(){
		S = this;
	}
	// Use this for initialization
	void Start () {
		gameObject.SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.A)) {
			if(isStats1 == true){
				isStats1 = false;
				Stats1.S.gameObject.SetActive(false);
				isStats2 = true;
				Stats2.S.gameObject.SetActive(true);
			}
			else if(isStats2){
				Stats1.S.gameObject.SetActive(true);
				Stats2.S.gameObject.SetActive(true);
				gameObject.SetActive(false);
				PartyOption.S.isShowStats = false;
			}
		}
	}
}
