﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
public class EnemyPokemon : MonoBehaviour {

	public static EnemyPokemon S;
	public PokemonAttribute current;
	public List<GameObject> attributeItems;
	public static List<PokemonAttribute> EnemyList = new List<PokemonAttribute>();
	public float time = 0;
	public int C = 1;
	public int segfault = 0;
	public int timeExceed = 0;
	public MoveAttribute currentMove;
	void Awake(){
		S = this;
	}
	// Use this for initialization
	void Start () {
		foreach (Transform child in transform) {
			attributeItems.Add(child.gameObject);


		}
	}
	
	// Update is called once per frame
	void Update () {
		if (EnemyList.Count == 0)
			return;
		if (Main.S.battle) {
			foreach(GameObject go in attributeItems){
				if(go.name == "Level"){
					go.GetComponent<GUIText>().text = current.level.ToString();
				}
				else if(go.name == "Name"){
					go.GetComponent<GUIText>().text = current.name;					
				}
					
			}
			if(BattleText.S.isCaughtTry){
				time += Time.deltaTime;
				if(time > 1f){
					float temp = Random.Range(0f,1f);
					if(temp <= 1f)
						BattleText.S.isCaughtSucceed = true;
					else 
						BattleText.S.isCaughtFailed = true;
					BattleText.S.isCaughtTry = false;
					time = 0;
				}
				if(time < 0.3f)
					gameObject.GetComponent<GUITexture> ().texture = Resources.Load("cloud") as Texture2D;
				else
					gameObject.GetComponent<GUITexture>().texture = Resources.Load("fullball") as Texture2D;
			}

			else if(BattleText.S.isCaughtFailed){
				gameObject.GetComponent<GUITexture> ().texture = Resources.Load(current.path_norm) as Texture2D;
				BattleText.S.isCaughtFailed = false;
				BattleText.S.gameObject.SetActive(true);
				BattleText.S.displayText("Failed to catch!!");
			}
			else if(BattleText.S.isCaughtSucceed){
				BattleText.S.gameObject.SetActive(true);
				BattleText.S.displayText("Yout got it!!!");

			}
			else
				gameObject.GetComponent<GUITexture> ().texture = Resources.Load(current.path_norm) as Texture2D;


		}
	}
	public void Attack(){
		if (currentMove.name == "segfault") {
			MyPokemon.S.segfault += EnemyPokemon.S.C * 2;
			C = 1;
			return;
		} else if (currentMove.name == "timeExceed") {
			MyPokemon.S.timeExceed += EnemyPokemon.S.C * 2 ;
			C = 1;
			return;
		}
		else if (currentMove.name == "C++") {
			C *= 2;
			return;
		}
		double damage = (double)((2 * current.level + 10)* current.atk * currentMove.power / (double)MyPokemon.current.def) / 250.0;
		print (damage);
		double STAB = currentMove.type == current.type ? 1.5 : 1;
		double Type = PokemonData.Effect [(int)current.type] [(int)MyPokemon.current.type];
		if (Type > 1)
			BattleText.S.isEnemyEffective = true;
		double critical = Random.Range (0, 2) > 0.5 ? 1.5 : 1;
		if(critical > 1)
			BattleText.S.isEnemyCritical = true;
		double random =  (double)Random.Range(0.85f, 1f);
		double modifier = STAB * Type * critical * random;
		damage = modifier * damage * (double)C;
		if (Main.S.isVincible && timeExceed == 0)
			damage = 0f;
		if (timeExceed > 0) {
			current.HP = current.HP - (int)damage < 0 ? 0 : current.HP - (int)damage;
		}
		else
			MyPokemon.current.HP =MyPokemon.current.HP - (int)damage < 0 ? 0 : MyPokemon.current.HP - (int)damage;
		BattleText.S.isLost = true;
		if (MyPokemon.current.HP > 0)
			BattleText.S.isLost = false;
		else {
			foreach (KeyValuePair<string,PokemonAttribute> item in MyPokemon.DictPokemon) {
				if (item.Value.HP != 0){
					MyPokemon.current = item.Value;
					BattleText.S.gameObject.SetActive(true);
					BattleText.S.displayText("Come back!! Go " + MyPokemon.current.name);
					BattleText.S.isLost = false;
					break;
				}
			}
		}
		if (BattleText.S.isMary && Mary_Lou_Dorf.S.currentPokemon < 2 && EnemyPokemon.S.current.HP <= 0) {

			Mary_Lou_Dorf.S.currentPokemon++;
			EnemyPokemon.S.current = Mary_Lou_Dorf.S.pokemonList[Mary_Lou_Dorf.S.currentPokemon];
			BattleText.S.isEnemySwitch = true;
		}		
		else if (BattleText.S.isDe && Deorio.S.currentPokemon < 2 && EnemyPokemon.S.current.HP <= 0) {
			
			Deorio.S.currentPokemon++;
			EnemyPokemon.S.current = Deorio.S.pokemonList[Deorio.S.currentPokemon];
			BattleText.S.isEnemySwitch = true;
			
			
		}
		else if (BattleText.S.isGib && Jeremy_bond.S.currentPokemon < 2 && EnemyPokemon.S.current.HP <= 0) {
			
			Jeremy_bond.S.currentPokemon++;
			EnemyPokemon.S.current = Jeremy_bond.S.pokemonList[Jeremy_bond.S.currentPokemon];
			BattleText.S.isEnemySwitch = true;
			
			
		}
		else if(EnemyPokemon.S.current.HP <= 0)
			BattleText.S.isWin = true;
		C = 1;
	}
	public void hideAttribute(){
		foreach (GameObject go in attributeItems) {
			go.SetActive(false);
		}
	}
	public void displayAttribute(){
		foreach (GameObject go in attributeItems) {
			go.SetActive(true);
		}
	}
}
