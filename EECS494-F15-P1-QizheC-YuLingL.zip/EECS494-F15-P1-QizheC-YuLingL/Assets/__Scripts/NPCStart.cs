﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
public class NPCStart : MonoBehaviour {

	public static NPCStart S;
	public GameObject NPCPicture;
	public List<GameObject> ballItems = new List<GameObject>();
	void Awake(){
		S = this;
	}
	// Use this for initialization
	void Start () {
		foreach (Transform child in transform) {
			print (child.gameObject.name);
			if(child.gameObject.name[0] == 'B')
				ballItems.Add(child.gameObject);
			else if(child.gameObject.name == "NPCPicture"){
				NPCPicture = child.gameObject;
				print ("NPCpicture");
			}
		}
		ballItems = ballItems.OrderByDescending(m => m.transform.transform.position.x).ToList ();
		
	}
	
	// Update is called once per frame
	void Update () {
		if (BattleText.S.isMary) {
			EnemyPokemon.S.current = Mary_Lou_Dorf.S.pokemonList [0];
			NPCStart.S.NPCPicture.gameObject.GetComponent<GUITexture> ().texture = Resources.Load ("mary") as Texture2D;
		} else if (BattleText.S.isDe) {
			EnemyPokemon.S.current = Deorio.S.pokemonList [0];
			NPCStart.S.NPCPicture.gameObject.GetComponent<GUITexture> ().texture = Resources.Load ("deorio") as Texture2D;
			
		} else if (BattleText.S.isGib) {
			EnemyPokemon.S.current = Jeremy_bond.S.pokemonList [0];
			NPCStart.S.NPCPicture.gameObject.GetComponent<GUITexture> ().texture = Resources.Load ("jeremy") as Texture2D;
			
		} else {
			NPCStart.S.NPCPicture.gameObject.GetComponent<GUITexture> ().texture = Resources.Load ("NPC1") as Texture2D;

		}

		if (Main.S.battle) {
			int count = 1;
			if(BattleText.S.isMary || BattleText.S.isDe || BattleText.S.isGib)
				count = 3;
			for(int i = 0; i < count; i++)
			{
				ballItems[i].gameObject.GetComponent<GUITexture>().texture = Resources.Load("fullball") as Texture2D;
			}
			for(int i = count; i < 6; i++)
			{
				ballItems[i].gameObject.GetComponent<GUITexture>().texture = Resources.Load("emptyball") as Texture2D;
			}
		}
	}
}

