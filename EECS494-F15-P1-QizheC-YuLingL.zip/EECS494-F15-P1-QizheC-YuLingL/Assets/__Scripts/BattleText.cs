﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
public class BattleText : MonoBehaviour {

	public static BattleText S; 
	public string enemyMove;
	public bool myAttack = false;
	public bool enemyAttack = false;
	public bool isWin = false;
	public bool isLost = false;
	public bool isWinFinish = false;
	public bool isLostFinish = false;
	public bool isStart = true;
	public bool isGo = false;
	public bool isWild = false;
	public bool isShowExp = false;
	public bool isNPC = false;
	public bool isNPCGo = false;
	public bool isLevelUp = false;
	public bool isEffective = false;
	public bool isCritical = false;
	public bool isEnemyEffective = false;
	public bool isEnemyCritical = false;
	public bool isCaughtTry = false;
	public bool isShowBall = false;
	public bool isCaughtSucceed = false;
	public bool isCaughtFailed = false;
	public bool isEnemySwitch = false;
	public bool isMary = false;
	public bool is281 = false;
	public bool isDe = false;
	public bool isGib = false;
	public bool isMySegfault = false;
	public bool isEnemySegfault = false;
	public bool isMyTimeExceed = false;
	public bool isEnemyTimeExceed = false;
	// Use this for initialization
	void Awake(){
		S = this;
	}
	void Start () {
		gameObject.SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {

		if (Input.GetKeyDown(KeyCode.A)) {
			if(isEffective && isCritical ){
				displayText(MyPokemon.current.name + "'s attack is super-effective!");
				isCritical = false;
			}
			else if (isLost) {
				displayText ("You have no pokemon can be used in your party! You Lost!");
				isLostFinish = true;
				isLost = false;
			} else if (isWin) {
				displayText ("You Win! The enemy pokemon faintied");
				isShowExp = true;
				isWin = false;
			}
			else if (isShowExp) {
				int experience = 0;
				/*if(EnemyPokemon.S.current.levelType == "MS")
					//experience = PokemonData.MS[EnemyPokemon.S.current.level];
				else {
					//experience = PokemonData.MF[EnemyPokemon.S.current.level];
				}*/
				if(isNPC)
					experience = (int)(experience * 1.5);
				int gold = Random.Range(100,200);
				Player.S.money += gold;
				displayText(MyPokemon.current.name + " get EXP " + experience.ToString() + '\n' + "You got " + gold.ToString() + " gold!");
				MyPokemon.current.curExp += experience;
				if(isMary || isDe || isGib){
					foreach (KeyValuePair<string,PokemonAttribute> item in MyPokemon.DictPokemon) {
			
						item.Value.HP = item.Value.MaxHP;
						item.Value.Move1PP = PokemonData.DictMove[item.Value.Move1].MaxPP;
						if(item.Value.Move2 != null)
							item.Value.Move2PP = PokemonData.DictMove[item.Value.Move2].MaxPP;
						if(item.Value.Move3 != null)
							item.Value.Move3PP = PokemonData.DictMove[item.Value.Move3].MaxPP;


					}
				}
				isWinFinish = true;
				/*
				if(MyPokemon.current.levelType == "MS"){
					if(MyPokemon.current.curExp > PokemonData.MS[MyPokemon.current.level]){
						MyPokemon.current.curExp -= PokemonData.MS[MyPokemon.current.level];
						MyPokemon.current.level++;
						isLevelUp = true;
					}
					else {
						isWinFinish = true;
					}
					
				}
				else{
					if(MyPokemon.current.curExp > PokemonData.MF[MyPokemon.current.level]){
						MyPokemon.current.curExp -= PokemonData.MF[MyPokemon.current.level];
						MyPokemon.current.level++;
						isLevelUp = true;

					}
					else{
						isWinFinish = true;
					}
				}*/
				isShowExp = false;
			}
			else if(isLevelUp){
				isWinFinish = true;
				displayText(MyPokemon.current.name + " grew up to "+"\n" + "level " + MyPokemon.current.level.ToString());
				isLevelUp = false;
			}
			else if(isStart){
				isStart = false;
				if(isNPC){
					if(isMary)
						displayText("Mary Lou Dorf sent out " + EnemyPokemon.S.current.name);
					else if(isDe)
						displayText("De Orio sent out " + EnemyPokemon.S.current.name);
					else if(isGib)
						displayText("Gibson sent out " + EnemyPokemon.S.current.name);
					else
						displayText("BLUE sent out " + EnemyPokemon.S.current.name);

					NPCStart.S.gameObject.SetActive(false);
					EnemyPokemon.S.gameObject.SetActive(true);
					EnemyPokemon.S.hideAttribute();
					isNPCGo = true;
				}
				else{
					displayText("Go !" + MyPokemon.current.name + "!");
					isGo = true;
					MyPokemon.S.gameObject.SetActive(true);
					ShowMyBall.S.gameObject.SetActive(false);


				}
			}
			else if(isNPCGo){
				isNPCGo = false;
				isGo = true;
				displayText("Go !" + MyPokemon.current.name + "!");
				MyPokemon.S.gameObject.SetActive(true);
				ShowMyBall.S.gameObject.SetActive(false);

			}
			else if(isGo){
					EnemyPokemon.S.displayAttribute();
				Option.S.gameObject.SetActive(true);
				Main.S.isOption = true;
				isGo = false;
			}
			else if(isCaughtSucceed){
				PokemonAttribute newOne = new PokemonAttribute();
				newOne.name = EnemyPokemon.S.current.name;
				newOne.HP = EnemyPokemon.S.current.HP;
				newOne.atk = EnemyPokemon.S.current.atk;
				newOne.def = EnemyPokemon.S.current.def;
				newOne.special = EnemyPokemon.S.current.special;
				newOne.speed = EnemyPokemon.S.current.speed;
				newOne.level = EnemyPokemon.S.current.level;
				newOne.Move1 = EnemyPokemon.S.current.Move1;
				newOne.Move1PP = PokemonData.DictMove[newOne.Move1].MaxPP;
				if(Random.value < 0.8){
					newOne.Move2 = "debug";
					newOne.Move2PP = PokemonData.DictMove[newOne.Move2].MaxPP;

				}
				else {
					newOne.Move2 = "segfault";
					newOne.Move2PP = PokemonData.DictMove[newOne.Move2].MaxPP;
				}
				newOne.path_back = EnemyPokemon.S.current.path_back;
				newOne.path_norm = EnemyPokemon.S.current.path_norm;
				print (EnemyPokemon.S.current.path_back);
				newOne.MaxHP = EnemyPokemon.S.current.MaxHP;
				newOne.HP = EnemyPokemon.S.current.HP;
				foreach(KeyValuePair<string, PokemonAttribute> entry in MyPokemon.DictPokemon)
				{
					if(entry.Key == newOne.name){
						newOne.name += '1';
					}
				}
				MyPokemon.DictPokemon.Add (newOne.name,newOne);
				isCaughtSucceed = false;

				Main.S.battle = false;
			}
			else if(isMySegfault || isMyTimeExceed){
				isMySegfault = false;
				isMyTimeExceed = false;
				if(isEnemySwitch == false){
					string text = "";
					decideMove();
					text += EnemyPokemon.S.current.name + "\n" + "used " + EnemyPokemon.S.currentMove.name;
					if(EnemyPokemon.S.C > 1)
						text += "\n  C++ EFFECT";
					displayText(text);

					enemyAttack = true;
				}else{
					enemyAttack = true;
					if(isMary)
						BattleText.S.displayText("Mary switch the pokemon");
					else if(isDe)
						BattleText.S.displayText("Deorio switch the pokemon");
					else if(isGib)
						BattleText.S.displayText("Jeremy switch the pokemon");
				}
			}
			else if(myAttack){
				print (1);
				if(MyPokemon.S.segfault > 0){
					if(MyPokemon.currentMove == "debug"){
						displayText("Solve the segfault!! Nice debug!");
						MyPokemon.S.segfault = 0;
					}
					else{
						displayText("ALL shit!! Segfault! No effect caused!!!");
						MyPokemon.S.segfault--;
						
					}
					myAttack = false;
					isMySegfault = true;
					return;
				}
				if(MyPokemon.S.timeExceed > 0 && PokemonData.DictMove[MyPokemon.currentMove].category != Category.AFFECTED){
					MyPokemon.S.Attack();
					displayText("Time exceeds Limit~~ \n your pokemon attacks itself!");
					MyPokemon.S.timeExceed--;
					myAttack = false;
					isMyTimeExceed = true;
					return;
				}
				if(MyPokemon.currentMove == "algorithm" && MyPokemon.S.timeExceed > 0){
					displayText("improve the time complexity! \n good job!");
					MyPokemon.S.timeExceed = 0;
					myAttack = false;
					isMyTimeExceed = true;
					return;
				}
				MyPokemon.S.Attack();
				myAttack = false;
				if(isCritical == false && isEffective == false){
					if(isEnemySwitch == false){
						string text = "";
						decideMove();
						text += EnemyPokemon.S.current.name + "\n" + "used " + EnemyPokemon.S.currentMove.name;
						if(EnemyPokemon.S.C > 1)
							text += "\n  C++ EFFECT";
						displayText(text);
						
						enemyAttack = true;
					}
					else{
						enemyAttack = true;
						if(isMary)
						BattleText.S.displayText("Mary switch the pokemon");
						else if(isDe)
							BattleText.S.displayText("Deorio switch the pokemon");
						else if(isGib)
							BattleText.S.displayText("Jeremy switch the pokemon");

					}
				}
				else if(isCritical){
					displayText(MyPokemon.current.name + " did a critical damage!!");
				}
				else if(isEffective){
					displayText(MyPokemon.current.name + "'s attack is super-effective!");
				}


			}
			else if(isLostFinish || isWinFinish){
				if(isWinFinish){
					if(isMary){
						Dialog.S.ShowMessage("Your pokemon can learn new Skill  C++!! \n Press S and choose one Pokemon to learn");
						Party.S.learnMode = true;
						Party.S.learnMove = "C++";
					}
					else if(isDe){
						Dialog.S.ShowMessage("Your pokemon can learn new Skill  algorithm!! \n Press S and choose one Pokemon to learn");
						Party.S.learnMode = true;
						Party.S.learnMove = "segfault";
					}
				}
				if(isLostFinish){
				Vector3 v = new Vector3(-1f,73f,-0.01f);
				Player.S.gameObject.transform.position = v;
				Player.S.sprend.sprite = Player.S.upSprite;
				}
				isLostFinish = false;
				isWinFinish = false;
				Main.S.battle = false;
			}
			else if(isCritical){
				isCritical = false;
				if(isEnemySwitch == false){
					string text = "";
					decideMove();
					text += EnemyPokemon.S.current.name + "\n" + "used " + EnemyPokemon.S.currentMove.name;
					if(EnemyPokemon.S.C > 1)
						text += "\n  C++ EFFECT";
					displayText(text);
					
					enemyAttack = true;
				}
				else{
					enemyAttack = true;
					if(isMary)
						BattleText.S.displayText("Mary switch the pokemon");
					else if(isDe)
						BattleText.S.displayText("Deorio switch the pokemon");	
					else if(isGib)
						BattleText.S.displayText("Jeremy switch the pokemon");
				}
			}
			else if(isEffective){
				isEffective = false;
				if(isEnemySwitch == false){
					string text = "";
					decideMove();
					text += EnemyPokemon.S.current.name + "\n" + "used " + EnemyPokemon.S.currentMove.name;
					if(EnemyPokemon.S.C > 1)
						text += "\n  C++ EFFECT";
					displayText(text);
					
					enemyAttack = true;
				}
				else{
					enemyAttack = true;
					if(isMary)
						BattleText.S.displayText("Mary switch the pokemon");
					else if(isDe)
						BattleText.S.displayText("Deorio switch the pokemon");	
					else if(isGib)
						BattleText.S.displayText("Jeremy switch the pokemon");
				}
			}
			else if(isEnemySwitch){
				isEnemySwitch = false;
				if(enemyAttack){
					decideMove();
					string text ="";
					text += EnemyPokemon.S.current.name + "\n" + "used " + EnemyPokemon.S.currentMove.name;
					if(EnemyPokemon.S.C > 1)
						text += "\n  C++ EFFECT DOUBLE DAMAGE";
					displayText(text);
				}
				else{
					if(isMary)
						BattleText.S.displayText("Mary switch the pokemon");
					else if(isDe)
						BattleText.S.displayText("Deorio switch the pokemon");
					else if(isGib)
						BattleText.S.displayText("Jeremy switch the pokemon");
				}
			}
			else if(enemyAttack){
				if(EnemyPokemon.S.segfault > 0){
					if(EnemyPokemon.S.currentMove.name == "debug"){
						displayText("Solve the segfault!! Nice debug!");
						EnemyPokemon.S.segfault = 0;
					}
					else{
						displayText("ALL shit!! Segfault! No effect caused!!!");
						EnemyPokemon.S.segfault--;
						
					}
					enemyAttack = false;
					return;
				}
				if(EnemyPokemon.S.timeExceed > 0 && EnemyPokemon.S.currentMove.category != Category.AFFECTED){
					EnemyPokemon.S.Attack();
					displayText("Time exceeds Limit~~\n your pokemon attacks itself!");
					EnemyPokemon.S.timeExceed--;
					enemyAttack = false;
					isEnemyTimeExceed = true;
					return;
				}
				if(EnemyPokemon.S.currentMove.name == "algorithm" && EnemyPokemon.S.timeExceed > 0){
					displayText("improve the time complexity! \n good job!");
					EnemyPokemon.S.timeExceed = 0;
					enemyAttack = false;
					isEnemyTimeExceed = true;
					return;
				}
				EnemyPokemon.S.Attack();
				enemyAttack = false;
				if(isLost == false && isEnemySwitch == false){
					Main.S.isOption = true;
					Option.S.gameObject.SetActive(true);
					print (Option.S.gameObject.activeInHierarchy);
					gameObject.SetActive(false);
				}
			}
			else{
				Main.S.isOption = true;
				Option.S.gameObject.SetActive(true);
				print (Option.S.gameObject.activeInHierarchy);
				gameObject.SetActive(false);
			}

		}

	}
	public void decideMove(){
		if (EnemyPokemon.S.segfault > 0) {
			if(EnemyPokemon.S.current.Move1 == "debug" && EnemyPokemon.S.current.Move1PP > 0){
				EnemyPokemon.S.currentMove = PokemonData.DictMove [EnemyPokemon.S.current.Move1];
				EnemyPokemon.S.current.Move1PP--;
				return;

			}
			else if(EnemyPokemon.S.current.Move2 == "debug" && EnemyPokemon.S.current.Move2PP > 0){
				EnemyPokemon.S.currentMove = PokemonData.DictMove [EnemyPokemon.S.current.Move2];
				EnemyPokemon.S.current.Move2PP--;
				return;


			}
			else if(EnemyPokemon.S.current.Move3 == "debug" && EnemyPokemon.S.current.Move3PP > 0){
				EnemyPokemon.S.currentMove = PokemonData.DictMove [EnemyPokemon.S.current.Move3];
				EnemyPokemon.S.current.Move3PP--;
				return;


			}
			else if(EnemyPokemon.S.current.Move4 == "debug" && EnemyPokemon.S.current.Move4PP > 0){
				EnemyPokemon.S.currentMove = PokemonData.DictMove [EnemyPokemon.S.current.Move4];
				EnemyPokemon.S.current.Move4PP--;
				return;


			}
		}
		if (EnemyPokemon.S.timeExceed > 0) {
			if(EnemyPokemon.S.current.Move1 == "algorithm" && EnemyPokemon.S.current.Move1PP > 0){
				EnemyPokemon.S.currentMove = PokemonData.DictMove [EnemyPokemon.S.current.Move1];
				EnemyPokemon.S.current.Move1PP--;
				return;

			}
			else if(EnemyPokemon.S.current.Move2 == "algorithm" && EnemyPokemon.S.current.Move2PP > 0){
				EnemyPokemon.S.currentMove = PokemonData.DictMove [EnemyPokemon.S.current.Move2];
				EnemyPokemon.S.current.Move2PP--;
				return;


			}
			else if(EnemyPokemon.S.current.Move3 == "algorithm" && EnemyPokemon.S.current.Move3PP > 0){
				EnemyPokemon.S.currentMove = PokemonData.DictMove [EnemyPokemon.S.current.Move3];
				EnemyPokemon.S.current.Move3PP--;
				return;

			}
			else if(EnemyPokemon.S.current.Move4 == "algorithm" && EnemyPokemon.S.current.Move4PP > 0){
				EnemyPokemon.S.currentMove = PokemonData.DictMove [EnemyPokemon.S.current.Move4];
				EnemyPokemon.S.current.Move4PP--;
				return;
			}
		}
		int random1 = Random.Range (0, 4);
		if (random1 == 0)
			EnemyPokemon.S.currentMove = PokemonData.DictMove [EnemyPokemon.S.current.Move1];
		else if (random1 == 1 && EnemyPokemon.S.current.Move2 != null && EnemyPokemon.S.current.Move2PP > 0 && EnemyPokemon.S.current.Move2 != "algorithm" && EnemyPokemon.S.current.Move2 != "debug") {
			EnemyPokemon.S.currentMove = PokemonData.DictMove [EnemyPokemon.S.current.Move2];
			EnemyPokemon.S.current.Move2PP--;
		} else if (random1 == 2 && EnemyPokemon.S.current.Move3 != null && EnemyPokemon.S.current.Move3PP > 0 && EnemyPokemon.S.current.Move3 != "algorithm" && EnemyPokemon.S.current.Move3 != "debug") {
			EnemyPokemon.S.currentMove = PokemonData.DictMove [EnemyPokemon.S.current.Move3];
			EnemyPokemon.S.current.Move3PP--;
		} else if (random1 == 3 && EnemyPokemon.S.current.Move4 != null && EnemyPokemon.S.current.Move4PP > 0 && EnemyPokemon.S.current.Move4 != "algorithm" && EnemyPokemon.S.current.Move4 != "debug") {
			EnemyPokemon.S.currentMove = PokemonData.DictMove [EnemyPokemon.S.current.Move4];
			EnemyPokemon.S.current.Move4PP--;
		}
		else
			EnemyPokemon.S.currentMove = PokemonData.DictMove [EnemyPokemon.S.current.Move1];
	}
	public void displayText(string text){
		gameObject.GetComponent<GUIText>().text= text;
	}
}
